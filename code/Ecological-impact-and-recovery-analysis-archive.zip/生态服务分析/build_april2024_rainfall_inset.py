r"""生成江湾镇2024年4月降雨与历史同期对比小图。

输入：
1. GPM逐日降雨：E:\Raster_data\NASA GPM降水数据\南岭\{year}\GPM_Daily_yyyymmdd.tif
2. 江湾镇边界：E:\python_base\Slide_dect\Input\Jiangwan\Jiangwan.shp

统计口径：
1. 先按GPM像元与江湾镇边界的相交面积计算逐日区域加权平均降雨。
2. 对每年4月的30个逐日值求和，得到该年4月累计降雨量。
3. 以2018-2023年4月累计降雨量的均值和标准差作为历史同期统计。
"""

from __future__ import annotations

import re
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import box


GPM_ROOT = Path(r"E:\Raster_data\NASA GPM降水数据\南岭")
STUDY_AREA = Path(r"E:\python_base\Slide_dect\Input\Jiangwan\Jiangwan.shp")
RESULT_DIR = Path(r"E:\python_base\Slide_dect\Output\EcoService_DID\04_did_results")
FIGURE_DIR = Path(r"E:\python_base\Slide_dect\Output\EcoService_DID\05_figures")

TARGET_YEAR = 2024
MONTH = 4
HISTORICAL_YEARS = tuple(range(2018, TARGET_YEAR))
DATE_PATTERN = re.compile(r"GPM_Daily_(\d{8})\.tif$", re.IGNORECASE)


def _list_april_files(year: int) -> list[tuple[pd.Timestamp, Path]]:
    """列出指定年份4月的GPM逐日栅格，并从文件名解析日期。"""

    files: list[tuple[pd.Timestamp, Path]] = []
    for path in sorted((GPM_ROOT / str(year)).glob("GPM_Daily_*.tif")):
        match = DATE_PATTERN.match(path.name)
        if not match:
            continue
        date = pd.to_datetime(match.group(1), format="%Y%m%d")
        if date.month == MONTH:
            files.append((date, path))
    return files


def _build_overlap_weights(
    raster_path: Path,
    study_area_path: Path,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """计算江湾镇与GPM像元的相交面积权重。"""

    boundary = gpd.read_file(study_area_path)
    if boundary.empty:
        raise ValueError(f"研究区矢量为空：{study_area_path}")

    with rasterio.open(raster_path) as src:
        if src.crs is None:
            raise ValueError(f"降雨栅格缺少坐标系：{raster_path}")
        boundary = boundary.to_crs(src.crs)
        # 兼容当前环境中较早版本的GeoPandas。
        study_geometry = boundary.geometry.unary_union
        transform = src.transform

        # 只遍历研究区外包矩形覆盖到的行列，减少无效几何相交计算。
        minx, miny, maxx, maxy = study_geometry.bounds
        row_min, col_min = src.index(minx, maxy)
        row_max, col_max = src.index(maxx, miny)
        row_min = max(0, min(row_min, row_max) - 1)
        row_max = min(src.height - 1, max(row_min, row_max) + 1)
        col_min = max(0, min(col_min, col_max) - 1)
        col_max = min(src.width - 1, max(col_min, col_max) + 1)

        rows: list[int] = []
        cols: list[int] = []
        areas: list[float] = []
        for row in range(row_min, row_max + 1):
            for col in range(col_min, col_max + 1):
                left, bottom, right, top = rasterio.transform.array_bounds(
                    1,
                    1,
                    transform * rasterio.Affine.translation(col, row),
                )
                overlap_area = study_geometry.intersection(
                    box(left, bottom, right, top)
                ).area
                if overlap_area > 0:
                    rows.append(row)
                    cols.append(col)
                    areas.append(float(overlap_area))

    weights = np.asarray(areas, dtype="float64")
    if weights.size == 0 or weights.sum() <= 0:
        raise ValueError("研究区与降雨栅格没有有效空间交集。")
    weights /= weights.sum()
    return (
        np.asarray(rows, dtype="int64"),
        np.asarray(cols, dtype="int64"),
        weights,
    )


def _zonal_daily_mean(
    raster_path: Path,
    rows: np.ndarray,
    cols: np.ndarray,
    weights: np.ndarray,
) -> float:
    """按相交面积权重计算单日江湾镇平均降雨量。"""

    with rasterio.open(raster_path) as src:
        values = src.read(1)[rows, cols].astype("float64")
        valid = np.isfinite(values)
        if src.nodata is not None:
            valid &= values != src.nodata
        if not valid.any():
            return float("nan")
        valid_weights = weights[valid]
        valid_weights /= valid_weights.sum()
        return float(np.sum(values[valid] * valid_weights))


def build_tables() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """计算逐日值、各年4月总量和历史同期统计摘要。"""

    years = (*HISTORICAL_YEARS, TARGET_YEAR)
    first_files = _list_april_files(years[0])
    if not first_files:
        raise FileNotFoundError(f"未找到{years[0]}年4月GPM数据。")

    rows, cols, weights = _build_overlap_weights(first_files[0][1], STUDY_AREA)
    daily_records: list[dict[str, object]] = []

    for year in years:
        files = _list_april_files(year)
        if len(files) != 30:
            raise ValueError(f"{year}年4月应有30景，实际找到{len(files)}景。")
        for date, path in files:
            daily_records.append(
                {
                    "date": date.date().isoformat(),
                    "year": year,
                    "month": MONTH,
                    "daily_precipitation_mm": _zonal_daily_mean(
                        path, rows, cols, weights
                    ),
                    "source_file": str(path),
                }
            )

    daily = pd.DataFrame(daily_records)
    annual = (
        daily.groupby("year", as_index=False)
        .agg(
            april_total_precipitation_mm=("daily_precipitation_mm", "sum"),
            valid_days=("daily_precipitation_mm", "count"),
        )
        .sort_values("year")
    )

    historical = annual[annual["year"].isin(HISTORICAL_YEARS)][
        "april_total_precipitation_mm"
    ]
    target_total = float(
        annual.loc[
            annual["year"] == TARGET_YEAR, "april_total_precipitation_mm"
        ].iloc[0]
    )
    historical_mean = float(historical.mean())
    historical_sd = float(historical.std(ddof=1))
    anomaly_mm = target_total - historical_mean
    anomaly_percent = (
        anomaly_mm / historical_mean * 100.0 if historical_mean != 0 else np.nan
    )
    z_score = anomaly_mm / historical_sd if historical_sd > 0 else np.nan

    summary = pd.DataFrame(
        [
            {
                "group": f"{HISTORICAL_YEARS[0]}-{HISTORICAL_YEARS[-1]} April mean",
                "april_precipitation_mm": historical_mean,
                "sd_mm": historical_sd,
                "n_years": len(HISTORICAL_YEARS),
                "anomaly_from_historical_mean_mm": 0.0,
                "anomaly_from_historical_mean_percent": 0.0,
                "z_score_against_historical_aprils": 0.0,
            },
            {
                "group": f"{TARGET_YEAR} April",
                "april_precipitation_mm": target_total,
                "sd_mm": np.nan,
                "n_years": 1,
                "anomaly_from_historical_mean_mm": anomaly_mm,
                "anomaly_from_historical_mean_percent": anomaly_percent,
                "z_score_against_historical_aprils": z_score,
            },
        ]
    )
    return daily, annual, summary


def draw_inset(summary: pd.DataFrame) -> None:
    """绘制适合放入研究区图左下角的紧凑柱状图。"""

    historical_mean = float(summary.iloc[0]["april_precipitation_mm"])
    historical_sd = float(summary.iloc[0]["sd_mm"])
    target_total = float(summary.iloc[1]["april_precipitation_mm"])

    # 直接使用Pillow绘制，规避部分Windows环境中Matplotlib导出时的底层崩溃。
    width, height = 1890, 1470
    image = Image.new("RGBA", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font_regular = r"C:\Windows\Fonts\arial.ttf"
    font_bold = r"C:\Windows\Fonts\arialbd.ttf"
    title_font = ImageFont.truetype(font_bold, 74)
    label_font = ImageFont.truetype(font_regular, 54)
    tick_font = ImageFont.truetype(font_regular, 48)
    value_font = ImageFont.truetype(font_bold, 52)

    left, right, top, bottom = 285, 1810, 180, 1190
    plot_width = right - left
    plot_height = bottom - top
    y_data_max = max(historical_mean + historical_sd, target_total)
    y_axis_max = float(np.ceil(y_data_max * 1.15 / 250.0) * 250.0)

    def y_pixel(value: float) -> float:
        return bottom - value / y_axis_max * plot_height

    # 标题、网格、坐标轴和刻度。
    title = "April rainfall"
    title_box = draw.textbbox((0, 0), title, font=title_font)
    draw.text(
        ((width - (title_box[2] - title_box[0])) / 2, 36),
        title,
        fill="#111111",
        font=title_font,
    )
    tick_values = np.linspace(0, y_axis_max, 5)
    for tick in tick_values:
        y = y_pixel(float(tick))
        draw.line((left, y, right, y), fill="#D8D8D8", width=3)
        text_value = f"{tick:.0f}"
        text_box = draw.textbbox((0, 0), text_value, font=tick_font)
        draw.text(
            (left - 25 - (text_box[2] - text_box[0]), y - 25),
            text_value,
            fill="#202020",
            font=tick_font,
        )
    draw.line((left, top, left, bottom), fill="#1A1A1A", width=6)
    draw.line((left, bottom, right, bottom), fill="#1A1A1A", width=6)

    centers = [left + plot_width * 0.30, left + plot_width * 0.72]
    bar_width = 360
    values = [historical_mean, target_total]
    colors = ["#A7B8C8", "#D95F3D"]
    labels = ["2018-2023\nmean", "2024"]
    for bar_index, (center, value, color, label) in enumerate(
        zip(centers, values, colors, labels)
    ):
        y = y_pixel(value)
        draw.rectangle(
            (center - bar_width / 2, y, center + bar_width / 2, bottom),
            fill=color,
            outline="#202020",
            width=6,
        )
        value_text = f"{value:.0f}"
        value_box = draw.textbbox((0, 0), value_text, font=value_font)
        value_label_y = (
            y_pixel(historical_mean + historical_sd) - 72
            if bar_index == 0
            else y - 72
        )
        draw.text(
            (center - (value_box[2] - value_box[0]) / 2, value_label_y),
            value_text,
            fill="#202020",
            font=value_font,
        )
        label_lines = label.split("\n")
        for line_index, line in enumerate(label_lines):
            label_box = draw.textbbox((0, 0), line, font=tick_font)
            draw.text(
                (
                    center - (label_box[2] - label_box[0]) / 2,
                    bottom + 38 + line_index * 54,
                ),
                line,
                fill="#202020",
                font=tick_font,
            )

    # 历史均值柱使用±1 SD误差棒。
    error_center = centers[0]
    error_top = y_pixel(historical_mean + historical_sd)
    error_bottom = y_pixel(max(0.0, historical_mean - historical_sd))
    draw.line((error_center, error_top, error_center, error_bottom), fill="#202020", width=7)
    draw.line((error_center - 45, error_top, error_center + 45, error_top), fill="#202020", width=7)
    draw.line((error_center - 45, error_bottom, error_center + 45, error_bottom), fill="#202020", width=7)

    # 旋转后的纵轴标题。
    y_label = "April precipitation (mm)"
    y_label_image = Image.new("RGBA", (1100, 100), (255, 255, 255, 0))
    y_label_draw = ImageDraw.Draw(y_label_image)
    y_label_draw.text((0, 10), y_label, fill="#111111", font=label_font)
    y_label_image = y_label_image.rotate(90, expand=True)
    image.alpha_composite(y_label_image, (35, int((height - y_label_image.height) / 2)))

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    png_path = FIGURE_DIR / "Figure01_April2024_Rainfall_Inset.png"
    svg_path = FIGURE_DIR / "Figure01_April2024_Rainfall_Inset.svg"
    image.save(png_path, dpi=(600, 600))

    # 同时写出可在AI、Inkscape或Origin中继续编辑的简洁SVG版本。
    svg_bars: list[str] = []
    for bar_index, (center, value, color, label) in enumerate(
        zip(centers, values, colors, labels)
    ):
        y = y_pixel(value)
        svg_bars.append(
            f'<rect x="{center - bar_width / 2:.1f}" y="{y:.1f}" '
            f'width="{bar_width}" height="{bottom - y:.1f}" '
            f'fill="{color}" stroke="#202020" stroke-width="6"/>'
        )
        svg_value_y = error_top - 25 if bar_index == 0 else y - 25
        svg_bars.append(
            f'<text x="{center:.1f}" y="{svg_value_y:.1f}" text-anchor="middle" '
            f'font-family="Arial" font-size="52" font-weight="bold">{value:.0f}</text>'
        )
        label_svg = label.replace("\n", " ")
        svg_bars.append(
            f'<text x="{center:.1f}" y="{bottom + 75}" text-anchor="middle" '
            f'font-family="Arial" font-size="48">{label_svg}</text>'
        )
    svg_content = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<rect width="100%" height="100%" fill="white"/>
<text x="{width / 2}" y="100" text-anchor="middle" font-family="Arial" font-size="74" font-weight="bold">April rainfall</text>
<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="#1A1A1A" stroke-width="6"/>
<line x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}" stroke="#1A1A1A" stroke-width="6"/>
{''.join(svg_bars)}
<line x1="{error_center}" y1="{error_top:.1f}" x2="{error_center}" y2="{error_bottom:.1f}" stroke="#202020" stroke-width="7"/>
<line x1="{error_center - 45}" y1="{error_top:.1f}" x2="{error_center + 45}" y2="{error_top:.1f}" stroke="#202020" stroke-width="7"/>
<line x1="{error_center - 45}" y1="{error_bottom:.1f}" x2="{error_center + 45}" y2="{error_bottom:.1f}" stroke="#202020" stroke-width="7"/>
<text x="65" y="{height / 2}" text-anchor="middle" transform="rotate(-90 65 {height / 2})" font-family="Arial" font-size="54">April precipitation (mm)</text>
</svg>'''
    svg_path.write_text(svg_content, encoding="utf-8")


def main() -> None:
    """运行统计并写出表格与嵌图。"""

    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    daily, annual, summary = build_tables()

    daily.to_csv(
        RESULT_DIR / "Figure01_AprilRainfall_Daily_Jiangwan_2018_2024.csv",
        index=False,
        encoding="utf-8-sig",
    )
    annual.to_csv(
        RESULT_DIR / "Figure01_AprilRainfall_AnnualTotals_2018_2024.csv",
        index=False,
        encoding="utf-8-sig",
    )
    summary.to_csv(
        RESULT_DIR / "Figure01_AprilRainfall_2024_vs_Historical_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    draw_inset(summary)

    print(annual.to_string(index=False))
    print("\n2024年4月与历史同期统计：")
    print(summary.to_string(index=False))
    print(f"\n图件目录：{FIGURE_DIR}")
    print(f"数据目录：{RESULT_DIR}")


if __name__ == "__main__":
    main()
