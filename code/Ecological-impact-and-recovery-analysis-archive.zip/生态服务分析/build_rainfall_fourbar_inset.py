r"""生成江湾镇2024年与历史期年尺度、4月尺度降雨对比四柱图。

四根柱均采用统一统计口径：逐日区域平均降雨量的Mean ± SD。
历史期包括2018-2023年及2025年，目标年份为2024年。
"""

from __future__ import annotations

import calendar
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

# 复用已经验证过的空间相交面积加权函数。
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from build_april2024_rainfall_inset import (  # noqa: E402
    DATE_PATTERN,
    FIGURE_DIR,
    GPM_ROOT,
    RESULT_DIR,
    STUDY_AREA,
    _build_overlap_weights,
    _zonal_daily_mean,
)


TARGET_YEAR = 2024
HISTORICAL_YEARS = (2018, 2019, 2020, 2021, 2022, 2023, 2025)
ALL_YEARS = (*HISTORICAL_YEARS[:-1], TARGET_YEAR, HISTORICAL_YEARS[-1])

DAILY_CACHE = RESULT_DIR / "Figure01_Rainfall_Daily_Jiangwan_2018_2025.csv"
SUMMARY_CSV = RESULT_DIR / "Figure01_Rainfall_FourBar_MeanSD.csv"
ANNUAL_TOTAL_CSV = RESULT_DIR / "Figure01_Rainfall_AnnualTotals_2018_2025.csv"
PNG_PATH = FIGURE_DIR / "Figure01_Rainfall_Annual_April_FourBar_Inset.png"


def _list_year_files(year: int) -> list[tuple[pd.Timestamp, Path]]:
    """列出指定年份全部逐日GPM文件。"""

    records: list[tuple[pd.Timestamp, Path]] = []
    for path in sorted((GPM_ROOT / str(year)).glob("GPM_Daily_*.tif")):
        match = DATE_PATTERN.match(path.name)
        if not match:
            continue
        date = pd.to_datetime(match.group(1), format="%Y%m%d")
        records.append((date, path))
    return records


def build_or_read_daily_cache() -> pd.DataFrame:
    """优先读取完整缓存；缓存不存在或不完整时才重新提取栅格。"""

    expected_years = set(ALL_YEARS)
    if DAILY_CACHE.exists():
        cached = pd.read_csv(DAILY_CACHE)
        if {
            "date",
            "year",
            "month",
            "daily_precipitation_mm",
        }.issubset(cached.columns) and set(cached["year"].unique()) == expected_years:
            print(f"读取降雨缓存：{DAILY_CACHE}")
            return cached

    first_files = _list_year_files(ALL_YEARS[0])
    if not first_files:
        raise FileNotFoundError(f"没有找到{ALL_YEARS[0]}年的GPM数据。")
    rows, cols, weights = _build_overlap_weights(first_files[0][1], STUDY_AREA)

    records: list[dict[str, object]] = []
    for year in ALL_YEARS:
        files = _list_year_files(year)
        expected_days = 366 if calendar.isleap(year) else 365
        if len(files) != expected_days:
            print(f"警告：{year}年找到{len(files)}景，理论应有{expected_days}景。")
        for date, path in files:
            records.append(
                {
                    "date": date.date().isoformat(),
                    "year": year,
                    "month": int(date.month),
                    "daily_precipitation_mm": _zonal_daily_mean(
                        path, rows, cols, weights
                    ),
                    "source_file": str(path),
                }
            )

    daily = pd.DataFrame(records).sort_values("date").reset_index(drop=True)
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    daily.to_csv(DAILY_CACHE, index=False, encoding="utf-8-sig")
    return daily


def build_summary(daily: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """建立四柱统计和各年累计降雨统计。"""

    valid = daily[np.isfinite(daily["daily_precipitation_mm"])].copy()
    valid["period"] = np.where(valid["month"] == 4, "April", "Annual")

    rows: list[dict[str, object]] = []
    for period in ("Annual", "April"):
        period_data = valid if period == "Annual" else valid[valid["month"] == 4]
        for group, years in (
            ("Historical (2018-2023, 2025)", HISTORICAL_YEARS),
            ("2024", (TARGET_YEAR,)),
        ):
            values = period_data.loc[
                period_data["year"].isin(years), "daily_precipitation_mm"
            ].to_numpy(dtype="float64")
            rows.append(
                {
                    "period": period,
                    "group": group,
                    "mean_daily_precipitation_mm": float(np.mean(values)),
                    "sd_daily_precipitation_mm": float(np.std(values, ddof=1)),
                    "n_days": int(values.size),
                    "years": ";".join(str(year) for year in years),
                }
            )
    summary = pd.DataFrame(rows)

    annual_total = (
        valid.groupby("year", as_index=False)
        .agg(
            annual_total_precipitation_mm=("daily_precipitation_mm", "sum"),
            annual_mean_daily_precipitation_mm=("daily_precipitation_mm", "mean"),
            annual_sd_daily_precipitation_mm=("daily_precipitation_mm", "std"),
            valid_days=("daily_precipitation_mm", "count"),
        )
        .sort_values("year")
    )
    return summary, annual_total


def draw_four_bar(summary: pd.DataFrame) -> None:
    """用Pillow输出适合地图左下角嵌入的四柱图。"""

    ordered = summary.set_index(["period", "group"])
    keys = [
        ("Annual", "Historical (2018-2023, 2025)"),
        ("Annual", "2024"),
        ("April", "Historical (2018-2023, 2025)"),
        ("April", "2024"),
    ]
    means = [float(ordered.loc[key, "mean_daily_precipitation_mm"]) for key in keys]
    sds = [float(ordered.loc[key, "sd_daily_precipitation_mm"]) for key in keys]

    width, height = 2300, 1500
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    regular = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 46)
    bold = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 54)
    title_font = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 70)

    left, right, top, bottom = 285, 2200, 180, 1190
    plot_height = bottom - top
    y_max = max(mean + sd for mean, sd in zip(means, sds))
    y_axis_max = float(np.ceil(y_max * 1.12 / 10.0) * 10.0)

    def yp(value: float) -> float:
        return bottom - value / y_axis_max * plot_height

    title = "Rainfall comparison"
    title_box = draw.textbbox((0, 0), title, font=title_font)
    draw.text(((width - title_box[2]) / 2, 35), title, fill="#111111", font=title_font)

    # 绘制统一坐标轴和水平网格。
    for tick in np.linspace(0, y_axis_max, 5):
        y = yp(float(tick))
        draw.line((left, y, right, y), fill="#D8D8D8", width=3)
        label = f"{tick:.0f}"
        box_ = draw.textbbox((0, 0), label, font=regular)
        draw.text((left - 25 - box_[2], y - 24), label, fill="#202020", font=regular)
    draw.line((left, top, left, bottom), fill="#1A1A1A", width=6)
    draw.line((left, bottom, right, bottom), fill="#1A1A1A", width=6)

    centers = [540, 930, 1510, 1900]
    bar_width = 255
    colors = ["#A7B8C8", "#D95F3D", "#A7B8C8", "#D95F3D"]
    short_labels = ["Historical", "2024", "Historical", "2024"]
    for center, mean, sd, color, label in zip(centers, means, sds, colors, short_labels):
        y = yp(mean)
        draw.rectangle(
            (center - bar_width / 2, y, center + bar_width / 2, bottom),
            fill=color,
            outline="#202020",
            width=6,
        )
        error_top = yp(mean + sd)
        error_bottom = yp(max(0.0, mean - sd))
        draw.line((center, error_top, center, error_bottom), fill="#202020", width=7)
        draw.line((center - 35, error_top, center + 35, error_top), fill="#202020", width=7)
        draw.line((center - 35, error_bottom, center + 35, error_bottom), fill="#202020", width=7)
        value = f"{mean:.1f}"
        value_box = draw.textbbox((0, 0), value, font=bold)
        draw.text(
            (center - value_box[2] / 2, error_top - 65),
            value,
            fill="#202020",
            font=bold,
        )
        label_box = draw.textbbox((0, 0), label, font=regular)
        draw.text(
            (center - label_box[2] / 2, bottom + 35),
            label,
            fill="#202020",
            font=regular,
        )

    # 在两组柱下方标明时间尺度。
    for center, label in ((735, "Annual"), (1705, "April")):
        box_ = draw.textbbox((0, 0), label, font=bold)
        draw.text((center - box_[2] / 2, bottom + 105), label, fill="#111111", font=bold)

    # 先按文字实际边界创建透明图层，再旋转并居中，避免纵轴标题被画布裁切。
    y_label = "Mean daily precipitation (mm/day)"
    label_bbox = draw.textbbox((0, 0), y_label, font=regular)
    label_width = label_bbox[2] - label_bbox[0] + 24
    label_height = label_bbox[3] - label_bbox[1] + 24
    label_image = Image.new(
        "RGBA", (label_width, label_height), (255, 255, 255, 0)
    )
    label_draw = ImageDraw.Draw(label_image)
    label_draw.text(
        (12 - label_bbox[0], 12 - label_bbox[1]),
        y_label,
        fill="#111111",
        font=regular,
    )
    label_image = label_image.rotate(90, expand=True)
    image.paste(
        label_image,
        (45, int((height - label_image.height) / 2)),
        label_image,
    )

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    image.save(PNG_PATH, dpi=(600, 600))


def main() -> None:
    """生成统计表和四柱嵌图。"""

    daily = build_or_read_daily_cache()
    summary, annual_total = build_summary(daily)
    summary.to_csv(SUMMARY_CSV, index=False, encoding="utf-8-sig")
    annual_total.to_csv(ANNUAL_TOTAL_CSV, index=False, encoding="utf-8-sig")
    draw_four_bar(summary)
    print(summary.to_string(index=False))
    print(f"\n图件：{PNG_PATH}")
    print(f"四柱统计：{SUMMARY_CSV}")
    print(f"年度总量：{ANNUAL_TOTAL_CSV}")


if __name__ == "__main__":
    main()
