"""生成 Fig.4 高程、坡度和八坡向的背景—滑坡分布数据与草图。

统计口径
--------
1. 研究区背景：江湾镇边界内全部有效栅格像元，频率表示面积占比。
2. 滑坡分布：每个滑坡斑块只计一次；高程、坡度采用斑块内像元均值。
3. 坡向采用圆均值，避免 359° 与 1° 的算术平均错误。
4. 坡向划分为 N、NE、E、SE、S、SW、W 和 NW 八个标准方向。

输出目录
--------
E:/python_base/Slide_dect/Output/EcoService_DID/06_figure_source_data/
Fig04_Landslide_Distribution/Terrain_Comparison/
"""
from __future__ import annotations

from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import rasterio
from plotly.subplots import make_subplots
from rasterio.mask import mask
from scipy.spatial.distance import jensenshannon
from scipy.stats import ks_2samp


PROJECT_ROOT = Path(r"E:\python_base\Slide_dect")
OUTPUT_ROOT = PROJECT_ROOT / "Output" / "EcoService_DID"
SOURCE_DIR = (
    OUTPUT_ROOT
    / "06_figure_source_data"
    / "Fig04_Landslide_Distribution"
    / "Terrain_Comparison"
)
EVENTS_PATH = OUTPUT_ROOT / "01_landslide_events.gpkg"
STUDY_AREA_PATH = PROJECT_ROOT / "Input" / "Jiangwan" / "Jiangwan.shp"
ELEVATION_PATH = PROJECT_ROOT / "Input" / "高程数据" / "ALOS_PALSAR_DEM.tif"
SLOPE_PATH = PROJECT_ROOT / "Output" / "Slope.tif"
ASPECT_PATH = PROJECT_ROOT / "Output" / "Aspect.tif"
PRE_EVENT_LAI_PATH = (
    OUTPUT_ROOT
    / "06_figure_source_data"
    / "Fig04_Landslide_Distribution"
    / "Fig04B_PreEvent_LAI_OverlayFrequency.csv"
)

ELEVATION_EDGES = np.arange(100.0, 1400.0 + 100.0, 100.0)
SLOPE_EDGES = np.asarray([0.0, 10.0, 20.0, 30.0, 90.0])
ASPECT_8_CLASS_LABELS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
ASPECT_8_CATEGORIES = ["NW", "N", "NE", "E", "SE", "S", "SW", "W"]


def _labels(edges: np.ndarray, unit: str) -> list[str]:
    """生成不会被 Excel 识别为日期的分箱标签。"""
    labels: list[str] = []
    for left, right in zip(edges[:-1], edges[1:]):
        if unit == "deg" and right == 90:
            labels.append(">30 deg")
        else:
            labels.append(f"{left:g}-{right:g} {unit}")
    return labels


def _valid_values(masked: np.ma.MaskedArray, variable: str) -> np.ndarray:
    """清理掩膜、非有限值及变量物理范围外的值。"""
    values = np.asarray(masked.compressed(), dtype=np.float64)
    values = values[np.isfinite(values)]
    if variable == "elevation":
        return values[(values >= -100.0) & (values <= 9000.0)]
    if variable == "slope":
        return values[(values >= 0.0) & (values <= 90.0)]
    return values[(values >= 0.0) & (values <= 360.0)]


def _read_background(path: Path, variable: str) -> np.ndarray:
    """读取江湾镇边界内全部有效像元。"""
    with rasterio.open(path) as src:
        study = gpd.read_file(STUDY_AREA_PATH).to_crs(src.crs)
        geoms = [
            geom.__geo_interface__
            for geom in study.geometry
            if geom is not None and not geom.is_empty
        ]
        data, _ = mask(src, geoms, crop=True, filled=False, indexes=1)
    return _valid_values(data, variable)


def _circular_mean_degrees(values: np.ndarray) -> tuple[float, float]:
    """返回坡向圆均值和平均向量长度；后者反映坡向集中程度。"""
    if values.size == 0:
        return np.nan, np.nan
    radians = np.deg2rad(values)
    sin_mean = float(np.mean(np.sin(radians)))
    cos_mean = float(np.mean(np.cos(radians)))
    strength = float(np.hypot(sin_mean, cos_mean))
    angle = float(np.rad2deg(np.arctan2(sin_mean, cos_mean)) % 360.0)
    return angle, strength


def _circular_summary_degrees(values: np.ndarray) -> tuple[float, float]:
    """计算坡向圆均值和圆标准差，避免跨越 0° 时的算术平均错误。"""
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan, np.nan
    mean_deg, strength = _circular_mean_degrees(values)
    strength = float(np.clip(strength, np.finfo(float).tiny, 1.0))
    circular_sd_deg = float(np.rad2deg(np.sqrt(-2.0 * np.log(strength))))
    return mean_deg, circular_sd_deg


def _zonal_event_values(events: gpd.GeoDataFrame) -> pd.DataFrame:
    """逐滑坡提取三类地形指标，保证所有指标使用同一事件几何。"""
    rasters = {
        "elevation": rasterio.open(ELEVATION_PATH),
        "slope": rasterio.open(SLOPE_PATH),
        "aspect": rasterio.open(ASPECT_PATH),
    }
    projected = {
        name: events.to_crs(src.crs)
        for name, src in rasters.items()
    }
    rows: list[dict[str, object]] = []
    try:
        for index, event in events.iterrows():
            row: dict[str, object] = {
                "event_id": str(event["event_id"]),
                "event_year": int(event["event_year"]),
                "area_m2": float(event["area_m2"]),
            }
            for variable, src in rasters.items():
                geom = projected[variable].geometry.iloc[index]
                try:
                    data, _ = mask(
                        src,
                        [geom.__geo_interface__],
                        crop=True,
                        filled=False,
                        indexes=1,
                    )
                    values = _valid_values(data, variable)
                except (ValueError, IndexError):
                    values = np.asarray([], dtype=float)
                row[f"{variable}_n_pixels"] = int(values.size)
                if variable == "aspect":
                    mean, strength = _circular_mean_degrees(values)
                    row["aspect_circular_mean_deg"] = mean
                    row["aspect_vector_strength"] = strength
                else:
                    row[f"{variable}_mean"] = (
                        float(np.mean(values)) if values.size else np.nan
                    )
                    row[f"{variable}_sd"] = (
                        float(np.std(values, ddof=0)) if values.size else np.nan
                    )
            rows.append(row)
            if (index + 1) % 500 == 0:
                print(f"[events] {index + 1}/{len(events)}")
    finally:
        for src in rasters.values():
            src.close()
    result = pd.DataFrame(rows)
    angle = np.deg2rad(result["aspect_circular_mean_deg"])
    result["east_west_class"] = np.where(
        np.sin(angle) >= 0.0, "East-facing", "West-facing"
    )
    result["north_south_class"] = np.where(
        np.cos(angle) >= 0.0, "North-facing", "South-facing"
    )
    result.loc[result["aspect_circular_mean_deg"].isna(), [
        "east_west_class", "north_south_class"
    ]] = np.nan
    return result


def _frequency_numeric(
    background: np.ndarray,
    events: pd.Series,
    edges: np.ndarray,
    labels: list[str],
) -> pd.DataFrame:
    """构造背景像元面积占比与事件数量占比的并列频率表。"""
    event_values = pd.to_numeric(events, errors="coerce").dropna().to_numpy(float)
    bg_counts, _ = np.histogram(background, bins=edges)
    event_counts, _ = np.histogram(event_values, bins=edges)
    return pd.DataFrame(
        {
            "bin_order": np.arange(len(labels)),
            "bin_label": labels,
            "bin_left": edges[:-1],
            "bin_right": edges[1:],
            "background_pixel_count": bg_counts,
            "background_total_pixels": int(bg_counts.sum()),
            "background_frequency_percent": bg_counts / bg_counts.sum() * 100.0,
            "landslide_count": event_counts,
            "landslide_total": int(event_counts.sum()),
            "landslide_frequency_percent": event_counts / event_counts.sum() * 100.0,
        }
    )


def _aspect_classes(values: np.ndarray, mode: str) -> np.ndarray:
    """把像元坡向转换为东西坡或南北坡类别。"""
    radians = np.deg2rad(values)
    if mode == "east_west":
        return np.where(np.sin(radians) >= 0.0, "East-facing", "West-facing")
    return np.where(np.cos(radians) >= 0.0, "North-facing", "South-facing")


def _aspect_eight_classes(values: np.ndarray) -> np.ndarray:
    """按 45° 等间隔把坡向划分为八个标准方向。"""
    angle = np.asarray(values, dtype=float) % 360.0
    class_index = np.floor((angle + 22.5) / 45.0).astype(int) % 8
    categories = np.asarray(ASPECT_8_CLASS_LABELS, dtype=object)
    return categories[class_index]


def _frequency_category(
    background_classes: np.ndarray,
    event_classes: pd.Series,
    categories: list[str],
) -> pd.DataFrame:
    """构造二分类坡向的背景和滑坡频率表。"""
    event = event_classes.dropna().astype(str)
    rows = []
    for order, category in enumerate(categories):
        bg_count = int(np.sum(background_classes == category))
        event_count = int(np.sum(event == category))
        rows.append(
            {
                "bin_order": order,
                "bin_label": category,
                "background_pixel_count": bg_count,
                "background_total_pixels": int(background_classes.size),
                "background_frequency_percent": bg_count / background_classes.size * 100.0,
                "landslide_count": event_count,
                "landslide_total": int(event.size),
                "landslide_frequency_percent": event_count / event.size * 100.0,
            }
        )
    return pd.DataFrame(rows)


def _distribution_metrics(
    name: str,
    background: np.ndarray,
    events: pd.Series,
    frequency: pd.DataFrame,
) -> dict[str, object]:
    """计算连续变量的描述统计、分布距离和显著性。"""
    event_values = pd.to_numeric(events, errors="coerce").dropna().to_numpy(float)
    rng = np.random.default_rng(20260730)
    sample = (
        rng.choice(background, size=100_000, replace=False)
        if background.size > 100_000
        else background
    )
    pooled_sd = np.sqrt(
        (np.var(sample, ddof=1) + np.var(event_values, ddof=1)) / 2.0
    )
    bg_prob = frequency["background_frequency_percent"].to_numpy(float) / 100.0
    event_prob = frequency["landslide_frequency_percent"].to_numpy(float) / 100.0
    ks = ks_2samp(sample, event_values)
    return {
        "variable": name,
        "background_n": int(background.size),
        "background_mean": float(np.mean(background)),
        "background_sd": float(np.std(background, ddof=0)),
        "background_median": float(np.median(background)),
        "landslide_n": int(event_values.size),
        "landslide_mean": float(np.mean(event_values)),
        "landslide_sd": float(np.std(event_values, ddof=0)),
        "landslide_median": float(np.median(event_values)),
        "standardized_mean_difference": float(
            (np.mean(event_values) - np.mean(sample)) / pooled_sd
        ),
        "ks_D": float(ks.statistic),
        "ks_p": float(ks.pvalue),
        "total_variation_distance": float(0.5 * np.abs(bg_prob - event_prob).sum()),
        "jensen_shannon_distance": float(jensenshannon(bg_prob, event_prob)),
    }


def _category_metrics(name: str, frequency: pd.DataFrame) -> dict[str, object]:
    """计算坡向分类频率的分布距离。"""
    bg = frequency["background_frequency_percent"].to_numpy(float) / 100.0
    event = frequency["landslide_frequency_percent"].to_numpy(float) / 100.0
    return {
        "variable": name,
        "background_n": int(frequency["background_total_pixels"].iloc[0]),
        "landslide_n": int(frequency["landslide_total"].iloc[0]),
        "total_variation_distance": float(0.5 * np.abs(bg - event).sum()),
        "jensen_shannon_distance": float(jensenshannon(bg, event)),
        "maximum_percentage_point_difference": float(
            np.max(np.abs((event - bg) * 100.0))
        ),
    }


def _plot_preview(
    elevation: pd.DataFrame,
    slope: pd.DataFrame,
    aspect_eight: pd.DataFrame,
    pre_event_lai: pd.DataFrame,
) -> None:
    """生成用于快速审查的高程、坡度、八坡向和灾前 LAI 柱状图。"""
    fig = make_subplots(
        rows=2,
        cols=2,
        subplot_titles=(
            "(a) Elevation",
            "(b) Slope",
            "(c) Eight-direction aspect",
            "(d) Pre-event LAI",
        ),
        horizontal_spacing=0.11,
        vertical_spacing=0.22,
    )
    tables = [
        (elevation, 1, 1, "Elevation class"),
        (slope, 1, 2, "Slope class"),
        (aspect_eight, 2, 1, "Aspect direction"),
        (pre_event_lai, 2, 2, "Pre-event LAI class"),
    ]
    for index, (table, row, col, xlabel) in enumerate(tables):
        fig.add_trace(
            go.Bar(
                x=table["bin_label"],
                y=table["background_frequency_percent"],
                name="Study-area background",
                marker={"color": "#9BCF9B", "line": {"color": "black", "width": 0.7}},
                legendgroup="background",
                showlegend=index == 0,
            ),
            row=row,
            col=col,
        )
        fig.add_trace(
            go.Bar(
                x=table["bin_label"],
                y=table["landslide_frequency_percent"],
                name="Landslide polygon means",
                marker={"color": "#F3A35C", "line": {"color": "black", "width": 0.7}},
                legendgroup="landslide",
                showlegend=index == 0,
            ),
            row=row,
            col=col,
        )
        fig.update_xaxes(title_text=xlabel, tickangle=-35, row=row, col=col)
        fig.update_yaxes(title_text="Frequency (%)", row=row, col=col)
    fig.update_layout(
        template="plotly_white",
        barmode="group",
        width=1250,
        height=850,
        margin={"l": 75, "r": 35, "t": 90, "b": 90},
        legend={
            "orientation": "h",
            "x": 0.5,
            "xanchor": "center",
            "y": 1.12,
            "yanchor": "top",
        },
        font={"family": "Arial", "size": 15, "color": "black"},
    )
    fig.write_html(
        SOURCE_DIR / "Fig04_Terrain_Distribution_Comparison_Preview.html",
        include_plotlyjs=True,
        full_html=True,
    )


def main() -> None:
    """执行提取、统计、导出和草图生成。"""
    SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    event_cache = SOURCE_DIR / "Fig04_Terrain_EventLevel_Means.csv"
    if event_cache.exists():
        event_values = pd.read_csv(event_cache)
        print(f"[cache] Reusing {event_cache}")
    else:
        events = gpd.read_file(EVENTS_PATH)
        events = events.reset_index(drop=True)
        event_values = _zonal_event_values(events)

    elevation_bg = _read_background(ELEVATION_PATH, "elevation")
    slope_bg = _read_background(SLOPE_PATH, "slope")
    aspect_bg = _read_background(ASPECT_PATH, "aspect")

    elevation_labels = _labels(ELEVATION_EDGES, "m")
    slope_labels = _labels(SLOPE_EDGES, "deg")
    elevation = _frequency_numeric(
        elevation_bg, event_values["elevation_mean"], ELEVATION_EDGES, elevation_labels
    )
    slope = _frequency_numeric(
        slope_bg, event_values["slope_mean"], SLOPE_EDGES, slope_labels
    )
    east_west = _frequency_category(
        _aspect_classes(aspect_bg, "east_west"),
        event_values["east_west_class"],
        ["East-facing", "West-facing"],
    )
    north_south = _frequency_category(
        _aspect_classes(aspect_bg, "north_south"),
        event_values["north_south_class"],
        ["North-facing", "South-facing"],
    )
    event_values["aspect_8_class"] = pd.Series(
        pd.NA, index=event_values.index, dtype="object"
    )
    valid_aspect = event_values["aspect_circular_mean_deg"].notna()
    event_values.loc[valid_aspect, "aspect_8_class"] = _aspect_eight_classes(
        event_values.loc[valid_aspect, "aspect_circular_mean_deg"].to_numpy(float)
    )
    aspect_eight = _frequency_category(
        _aspect_eight_classes(aspect_bg),
        event_values["aspect_8_class"],
        ASPECT_8_CATEGORIES,
    )
    lai_source = pd.read_csv(PRE_EVENT_LAI_PATH)
    pre_event_lai = pd.DataFrame(
        {
            "bin_order": lai_source["bin_order"],
            "bin_label": lai_source["tick_label"],
            "background_pixel_count": lai_source["study_area_pixel_count_sum"],
            "background_total_pixels": lai_source["study_area_valid_pixels_sum"],
            "background_frequency_percent": lai_source[
                "study_area_frequency_percent"
            ],
            "landslide_count": lai_source["n_landslides"],
            "landslide_total": lai_source["denominator_landslides"],
            "landslide_frequency_percent": lai_source[
                "landslide_frequency_percent"
            ].fillna(0.0),
        }
    )

    # 为 Origin 制图补充可直接标注的描述统计。
    elevation_event = pd.to_numeric(
        event_values["elevation_mean"], errors="coerce"
    ).dropna()
    slope_event = pd.to_numeric(
        event_values["slope_mean"], errors="coerce"
    ).dropna()
    aspect_event = pd.to_numeric(
        event_values["aspect_circular_mean_deg"], errors="coerce"
    ).dropna().to_numpy(float)
    aspect_bg_mean, aspect_bg_sd = _circular_summary_degrees(aspect_bg)
    aspect_event_mean, aspect_event_sd = _circular_summary_degrees(aspect_event)
    lai_bg_mean = float(lai_source["background_mean"].dropna().iloc[0])
    lai_bg_sd = float(lai_source["background_sd"].dropna().iloc[0])
    lai_event_mean = float(lai_source["landslide_mean"].dropna().iloc[0])
    lai_event_sd = float(lai_source["landslide_sd"].dropna().iloc[0])

    summary = pd.DataFrame(
        [
            {
                "variable": "Elevation",
                "statistics_type": "arithmetic",
                "unit": "m",
                "background_n": int(elevation_bg.size),
                "background_mean": float(np.mean(elevation_bg)),
                "background_sd": float(np.std(elevation_bg, ddof=0)),
                "landslide_n": int(elevation_event.size),
                "landslide_mean": float(elevation_event.mean()),
                "landslide_sd": float(elevation_event.std(ddof=0)),
            },
            {
                "variable": "Slope",
                "statistics_type": "arithmetic",
                "unit": "degree",
                "background_n": int(slope_bg.size),
                "background_mean": float(np.mean(slope_bg)),
                "background_sd": float(np.std(slope_bg, ddof=0)),
                "landslide_n": int(slope_event.size),
                "landslide_mean": float(slope_event.mean()),
                "landslide_sd": float(slope_event.std(ddof=0)),
            },
            {
                "variable": "Aspect",
                "statistics_type": "circular",
                "unit": "degree",
                "background_n": int(aspect_bg.size),
                "background_mean": aspect_bg_mean,
                "background_sd": aspect_bg_sd,
                "landslide_n": int(aspect_event.size),
                "landslide_mean": aspect_event_mean,
                "landslide_sd": aspect_event_sd,
            },
            {
                "variable": "Pre-event LAI",
                "statistics_type": "arithmetic",
                "unit": "unitless",
                "background_n": int(lai_source["background_n"].dropna().iloc[0]),
                "background_mean": lai_bg_mean,
                "background_sd": lai_bg_sd,
                "landslide_n": int(lai_source["landslide_n"].dropna().iloc[0]),
                "landslide_mean": lai_event_mean,
                "landslide_sd": lai_event_sd,
            },
        ]
    )
    summary["background_mean_sd_label"] = summary.apply(
        lambda row: f"{row['background_mean']:.2f} ± {row['background_sd']:.2f}",
        axis=1,
    )
    summary["landslide_mean_sd_label"] = summary.apply(
        lambda row: f"{row['landslide_mean']:.2f} ± {row['landslide_sd']:.2f}",
        axis=1,
    )

    for table, variable in [
        (elevation, "Elevation"),
        (slope, "Slope"),
        (aspect_eight, "Aspect"),
        (pre_event_lai, "Pre-event LAI"),
    ]:
        stats = summary.loc[summary["variable"] == variable].iloc[0]
        for column in [
            "statistics_type",
            "background_mean",
            "background_sd",
            "landslide_mean",
            "landslide_sd",
            "background_mean_sd_label",
            "landslide_mean_sd_label",
        ]:
            table[column] = stats[column]

    metrics = pd.DataFrame(
        [
            _distribution_metrics(
                "Elevation", elevation_bg, event_values["elevation_mean"], elevation
            ),
            _distribution_metrics(
                "Slope", slope_bg, event_values["slope_mean"], slope
            ),
            _category_metrics("Aspect east-west", east_west),
            _category_metrics("Aspect north-south", north_south),
            _category_metrics("Aspect eight directions", aspect_eight),
            _category_metrics("Pre-event LAI", pre_event_lai),
        ]
    )
    metrics["main_figure_rank"] = metrics["total_variation_distance"].rank(
        method="dense", ascending=False
    )

    event_values.to_csv(
        SOURCE_DIR / "Fig04_Terrain_EventLevel_Means.csv",
        index=False,
        encoding="utf-8-sig",
    )
    # 独立统计表优先导出，避免 Origin 占用某张频率表时连汇总结果也无法保存。
    summary.to_csv(
        SOURCE_DIR / "Fig04_Descriptive_Statistics_Mean_SD.csv",
        index=False,
        encoding="utf-8-sig",
    )
    outputs = {
        "Elevation": elevation,
        "Slope": slope,
        "Aspect_EastWest": east_west,
        "Aspect_NorthSouth": north_south,
        "Aspect_EightDirections": aspect_eight,
        "PreEvent_LAI": pre_event_lai,
    }
    for name, table in outputs.items():
        output_path = (
            SOURCE_DIR / f"Fig04_{name}_Background_vs_Landslide_Frequency.csv"
        )
        try:
            table.to_csv(output_path, index=False, encoding="utf-8-sig")
        except PermissionError:
            # Origin 打开旧 CSV 时不能原位覆盖，另存完整新版以不中断其余导出。
            fallback_path = (
                SOURCE_DIR
                / f"Fig04_{name}_Background_vs_Landslide_Frequency_With_Mean_SD.csv"
            )
            table.to_csv(fallback_path, index=False, encoding="utf-8-sig")
            print(f"[locked] {output_path.name}; wrote {fallback_path.name}")
    metrics.to_csv(
        SOURCE_DIR / "Fig04_Terrain_Differentiation_Metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    with pd.ExcelWriter(
        SOURCE_DIR / "Fig04_Terrain_Distributions_All_SourceData.xlsx",
        engine="openpyxl",
    ) as writer:
        event_values.to_excel(writer, sheet_name="Event_Level_Means", index=False)
        elevation.to_excel(writer, sheet_name="Elevation_Frequency", index=False)
        slope.to_excel(writer, sheet_name="Slope_Frequency", index=False)
        east_west.to_excel(writer, sheet_name="Aspect_EW_Frequency", index=False)
        north_south.to_excel(writer, sheet_name="Aspect_NS_Frequency", index=False)
        aspect_eight.to_excel(
            writer, sheet_name="Aspect_8Dir_Frequency", index=False
        )
        pre_event_lai.to_excel(
            writer, sheet_name="PreEvent_LAI_Frequency", index=False
        )
        metrics.to_excel(writer, sheet_name="Differentiation_Metrics", index=False)
        summary.to_excel(writer, sheet_name="Mean_SD_Summary", index=False)

    _plot_preview(elevation, slope, aspect_eight, pre_event_lai)
    print(metrics.to_string(index=False))
    print(f"[done] {SOURCE_DIR}")


if __name__ == "__main__":
    main()
