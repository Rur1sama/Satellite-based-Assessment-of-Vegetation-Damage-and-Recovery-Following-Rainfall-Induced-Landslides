"""生成江湾镇年度滑坡统计简报图。

本脚本读取 Ensemble_Final_{year_pre}-{year_post}.tif 年度概率图，
按生态服务 DID 流程一致的阈值将概率图转为高置信滑坡掩膜，
统计年度滑坡面积和 8 邻域连通斑块数量，并输出一张 16:9 汇报用 PNG。
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


MASK_DIR = Path(r"E:\python_base\Slide_dect\Output\ML_Results\Ensemble_Final")
OUT_DIR = Path(r"E:\python_base\Slide_dect\Output\EcoService_DID\00_briefing")
MASK_PATTERN = "Ensemble_Final_*-*.tif"

# 与生态服务分析 config_example.json 里的 landslide.mask_threshold 保持一致。
MASK_THRESHOLD = 0.8

# 当前滑坡掩膜来自 Sentinel-2 10 m 栅格，因此单像元面积为 100 平方米。
PIXEL_AREA_M2 = 100.0


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """加载中文字体，避免 PIL 默认字体无法显示中文。"""
    candidates = [
        r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
        r"C:\Windows\Fonts\simsun.ttc",
    ]
    for candidate in candidates:
        if os.path.exists(candidate):
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def connected_components_stats(mask: np.ndarray) -> dict[str, float | int]:
    """用 8 邻域连通域估算独立滑坡斑块数量及斑块大小。"""
    height, width = mask.shape
    visited = np.zeros(mask.shape, dtype=bool)
    coords = np.argwhere(mask)
    sizes: list[int] = []

    for y0, x0 in coords:
        if visited[y0, x0] or not mask[y0, x0]:
            continue

        # 用显式栈做 flood-fill，避免依赖 scipy/skimage。
        stack = [(int(y0), int(x0))]
        visited[y0, x0] = True
        size = 0

        while stack:
            y, x = stack.pop()
            size += 1
            y1 = max(0, y - 1)
            y2 = min(height, y + 2)
            x1 = max(0, x - 1)
            x2 = min(width, x + 2)
            candidates = mask[y1:y2, x1:x2] & (~visited[y1:y2, x1:x2])
            if not candidates.any():
                continue
            yy, xx = np.where(candidates)
            for dy, dx in zip(yy, xx):
                ny = y1 + int(dy)
                nx = x1 + int(dx)
                visited[ny, nx] = True
                stack.append((ny, nx))

        sizes.append(size)

    arr = np.array(sizes, dtype=float)
    return {
        "patch_count": int(len(sizes)),
        "max_patch_pixels": int(arr.max()) if arr.size else 0,
        "mean_patch_pixels": float(arr.mean()) if arr.size else 0.0,
        "median_patch_pixels": float(np.median(arr)) if arr.size else 0.0,
    }


def compute_annual_stats() -> pd.DataFrame:
    """统计每个年度对的滑坡像元数、面积和斑块数量。"""
    rows: list[dict[str, float | int | str]] = []
    for path in sorted(MASK_DIR.glob(MASK_PATTERN)):
        match = re.search(r"_(\d{2})-(\d{2})\.tif$", path.name)
        if not match:
            continue

        year_pre = 2000 + int(match.group(1))
        year_post = 2000 + int(match.group(2))
        arr = np.array(Image.open(path), dtype=np.float32)
        valid = np.isfinite(arr)
        landslide_mask = valid & (arr > MASK_THRESHOLD)
        landslide_pixels = int(landslide_mask.sum())
        area_m2 = landslide_pixels * PIXEL_AREA_M2
        component_stats = connected_components_stats(landslide_mask)

        row = {
            "year_pair": f"{year_pre}-{year_post}",
            "event_year": year_post,
            "threshold": MASK_THRESHOLD,
            "landslide_pixels": landslide_pixels,
            "landslide_area_m2": area_m2,
            "landslide_area_ha": area_m2 / 10_000.0,
            "landslide_area_km2": area_m2 / 1_000_000.0,
            **component_stats,
        }
        row["max_patch_area_ha"] = row["max_patch_pixels"] * PIXEL_AREA_M2 / 10_000.0
        row["mean_patch_area_ha"] = row["mean_patch_pixels"] * PIXEL_AREA_M2 / 10_000.0
        row["median_patch_area_ha"] = row["median_patch_pixels"] * PIXEL_AREA_M2 / 10_000.0
        rows.append(row)

    return pd.DataFrame(rows)


def draw_briefing_slide(df: pd.DataFrame, out_png: Path) -> None:
    """把年度统计结果绘制成一张可直接放入 PPT 的 16:9 图片。"""
    width, height = 1920, 1080
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)

    font_title = load_font(46, True)
    font_sub = load_font(23)
    font_h = load_font(28, True)
    font = load_font(22)
    font_sm = load_font(18)
    font_num = load_font(38, True)
    font_axis = load_font(17)

    green = "#005826"
    green2 = "#1f8a4c"
    light_green = "#eef7f1"
    red = "#bf1734"
    orange = "#e8860c"
    grid = "#d9d9d9"

    # 页眉区域。
    draw.rectangle([0, 0, width, 98], fill="#f7f7f7")
    draw.rectangle([0, 0, 18, height], fill=green)
    draw.text((58, 28), "江湾镇滑坡年度简报", font=font_title, fill=green)
    draw.text(
        (58, 80),
        "基于 Ensemble_Final 年度滑坡概率图；阈值 > 0.8；10 m 像元面积估算",
        font=font_sub,
        fill="#555555",
    )

    total_area = float(df["landslide_area_ha"].sum())
    total_patches = int(df["patch_count"].sum())
    peak_area = df.loc[df["landslide_area_ha"].idxmax()]
    peak_count = df.loc[df["patch_count"].idxmax()]

    # 顶部四个核心指标卡片。
    cards = [
        ("累计高置信滑坡面积", f"{total_area:.2f} ha", "7 个年度对合计"),
        ("累计滑坡斑块数", f"{total_patches:,} 个", "8 邻域连通域估算"),
        ("面积峰值年份", f"{int(peak_area.event_year)}", f"{peak_area.landslide_area_ha:.2f} ha"),
        ("数量峰值年份", f"{int(peak_count.event_year)}", f"{int(peak_count.patch_count):,} 个"),
    ]
    card_w, card_h = 420, 132
    x0, y0, gap = 58, 132, 32
    for idx, (title, number, subtitle) in enumerate(cards):
        x = x0 + idx * (card_w + gap)
        draw.rounded_rectangle(
            [x, y0, x + card_w, y0 + card_h],
            radius=18,
            fill=light_green,
            outline="#cbd8cf",
            width=2,
        )
        draw.text((x + 24, y0 + 20), title, font=font, fill=green)
        draw.text((x + 24, y0 + 54), number, font=font_num, fill=red if idx in (2, 3) else green)
        draw.text((x + 24, y0 + 102), subtitle, font=font_sm, fill="#666666")

    # 左侧柱线图：柱表示面积，线表示斑块数量。
    plot_x, plot_y, plot_w, plot_h = 92, 330, 1140, 560
    years = df["event_year"].astype(int).tolist()
    areas = df["landslide_area_ha"].astype(float).tolist()
    patches = df["patch_count"].astype(float).tolist()
    max_area = max(max(areas), 1.0)
    max_patch = max(max(patches), 1.0)

    draw.text((plot_x, plot_y - 52), "年度滑坡面积与斑块数量", font=font_h, fill="#222222")
    for idx in range(6):
        y = plot_y + plot_h - int(plot_h * idx / 5)
        draw.line([plot_x, y, plot_x + plot_w, y], fill=grid, width=1)
        draw.text((plot_x - 70, y - 12), f"{max_area * idx / 5:.1f}", font=font_axis, fill="#555555")

    draw.line([plot_x, plot_y, plot_x, plot_y + plot_h], fill="#222222", width=2)
    draw.line([plot_x, plot_y + plot_h, plot_x + plot_w, plot_y + plot_h], fill="#222222", width=2)
    draw.text((plot_x - 80, plot_y - 25), "面积(ha)", font=font_axis, fill="#555555")

    bar_w = plot_w / (len(years) * 1.6)
    step = plot_w / len(years)
    line_points = []
    for idx, (year, area, patch_count) in enumerate(zip(years, areas, patches)):
        cx = plot_x + step * (idx + 0.5)
        bar_h = plot_h * area / max_area
        draw.rounded_rectangle(
            [cx - bar_w / 2, plot_y + plot_h - bar_h, cx + bar_w / 2, plot_y + plot_h],
            radius=5,
            fill=green2,
        )
        draw.text((cx - 22, plot_y + plot_h + 15), str(year), font=font_axis, fill="#333333")
        py = plot_y + plot_h - plot_h * patch_count / max_patch
        line_points.append((cx, py))

    for start, end in zip(line_points, line_points[1:]):
        draw.line([start, end], fill=orange, width=5)
    for cx, cy in line_points:
        draw.ellipse([cx - 7, cy - 7, cx + 7, cy + 7], fill=orange, outline="white", width=2)

    draw.text((plot_x + plot_w - 220, plot_y - 45), "绿色柱：面积(ha)", font=font_sm, fill=green2)
    draw.text((plot_x + plot_w - 220, plot_y - 20), "橙色线：斑块数(相对尺度)", font=font_sm, fill=orange)

    # 右侧年度表格。
    table_x, table_y, table_w, table_h = 1285, 318, 560, 600
    draw.text((table_x, table_y - 40), "年度统计表", font=font_h, fill="#222222")
    cols = [table_x, table_x + 110, table_x + 250, table_x + 390]
    headers = ["年份", "斑块数", "面积(ha)", "最大斑块(ha)"]
    draw.rounded_rectangle(
        [table_x - 10, table_y, table_x + table_w, table_y + table_h],
        radius=12,
        fill="#fbfbfb",
        outline="#cccccc",
        width=2,
    )
    draw.rectangle([table_x - 10, table_y, table_x + table_w, table_y + 44], fill=green)
    for idx, header in enumerate(headers):
        draw.text((cols[idx], table_y + 10), header, font=font_sm, fill="white")

    for idx, row in df.iterrows():
        y = table_y + 52 + idx * 62
        if idx % 2 == 0:
            draw.rectangle([table_x - 10, y - 8, table_x + table_w, y + 46], fill="#f2f6f3")
        values = [
            str(int(row.event_year)),
            f"{int(row.patch_count):,}",
            f"{row.landslide_area_ha:.2f}",
            f"{row.max_patch_area_ha:.2f}",
        ]
        for col_idx, value in enumerate(values):
            draw.text((cols[col_idx], y + 7), value, font=font, fill="#222222")

    # 底部可直接复制到汇报里的文字。
    note_y = 930
    row_2024 = df[df["event_year"] == 2024].iloc[0]
    narrative = (
        f"2024 年为重点灾害年份：高置信滑坡斑块 {int(row_2024.patch_count):,} 个，"
        f"面积 {row_2024.landslide_area_ha:.2f} ha。"
        f"2019-2025 年累计高置信滑坡面积 {total_area:.2f} ha，"
        f"面积峰值出现在 {int(peak_area.event_year)} 年。"
        "这些统计可作为后续 DID 事件研究、辐射区影响与生态损失估算的空间暴露基础。"
    )
    draw.rounded_rectangle([58, note_y, 1848, 1042], radius=14, fill="#fff8ef", outline="#edd2aa", width=2)
    draw.text((82, note_y + 18), "可直接放进汇报的表述：", font=font, fill=green)
    draw.text((82, note_y + 52), narrative, font=font_sm, fill="#333333")

    img.save(out_png, quality=95)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df = compute_annual_stats()
    csv_path = OUT_DIR / "jiangwan_landslide_annual_briefing_stats.csv"
    png_path = OUT_DIR / "jiangwan_landslide_annual_briefing_slide.png"
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    draw_briefing_slide(df, png_path)
    print(f"CSV: {csv_path}")
    print(f"PNG: {png_path}")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
