"""导出论文 Fig.4“滑坡分布规律”的制图源数据。

统计口径
--------
1. 滑坡分布：每个滑坡斑块只计一次，变量值为斑块内均值。
2. 研究区背景：统计江湾镇边界内全部有效像元，以像元占比表示面积占比。
3. 灾前 LAI：滑坡使用各自 t-1 年的 core 均值；研究区背景按相同灾前年份
   逐年统计，各年份先归一化后等权平均，不按滑坡数量加权。
4. 坡度：静态变量，统一使用 0-10、10-20、20-30 和 >30 度四档。

输出目录
--------
E:/python_base/Slide_dect/Output/EcoService_DID/06_figure_source_data/
Fig04_Landslide_Distribution/
"""
from __future__ import annotations

from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio.mask import mask


PROJECT_ROOT = Path(r"E:\python_base\Slide_dect")
OUTPUT_ROOT = PROJECT_ROOT / "Output" / "EcoService_DID"
DID_DIR = OUTPUT_ROOT / "04_did_results"
SOURCE_DIR = OUTPUT_ROOT / "06_figure_source_data" / "Fig04_Landslide_Distribution"

EVENTS_PATH = OUTPUT_ROOT / "01_landslide_events.gpkg"
PANEL_PATH = OUTPUT_ROOT / "03_zone_outcome_panel.csv"
FEATURE_PATH = DID_DIR / "recovery_rate_feature_table.csv"
STUDY_AREA_PATH = PROJECT_ROOT / "Input" / "Jiangwan" / "Jiangwan.shp"
SLOPE_RASTER_PATH = PROJECT_ROOT / "Output" / "Slope.tif"
LAI_RASTER_DIR = PROJECT_ROOT / "Output" / "SNAP_Results" / "Biophysical_SingleBand" / "LAI"

AREA_THRESHOLD_M2 = 1000.0
LAI_BIN_WIDTH = 0.5
LAI_BIN_EDGES = np.arange(0.0, 8.5 + LAI_BIN_WIDTH, LAI_BIN_WIDTH)
SLOPE_BIN_EDGES = np.asarray([0.0, 10.0, 20.0, 30.0, 90.0])
# CSV 中加入 deg，避免 Origin/Excel 把 10-20 自动识别为日期。
SLOPE_BIN_LABELS = ["0-10 deg", "10-20 deg", "20-30 deg", ">30 deg"]


def _size_class(area_m2: float) -> str:
    """按照论文统一口径把滑坡分为小滑坡和大滑坡。"""
    if pd.isna(area_m2):
        return "unknown"
    return "small_<1000m2" if float(area_m2) < AREA_THRESHOLD_M2 else "large_>=1000m2"


def _format_number(value: float) -> str:
    """把分箱边界格式化为简洁、稳定的文本。"""
    return str(int(value)) if float(value).is_integer() else f"{value:g}"


def _lai_labels() -> list[str]:
    """生成固定 0.5 间隔的 LAI 分箱标签。"""
    return [
        f"{_format_number(LAI_BIN_EDGES[i])}-{_format_number(LAI_BIN_EDGES[i + 1])}"
        for i in range(len(LAI_BIN_EDGES) - 1)
    ]


def _stats_row(
    variable: str,
    source: str,
    values: np.ndarray | pd.Series,
    weighting: str,
) -> dict[str, object]:
    """计算可直接用于图注的描述性统计量，SD采用总体标准差。"""
    array = pd.to_numeric(pd.Series(values), errors="coerce").dropna().to_numpy(dtype=float)
    if array.size == 0:
        return {
            "variable": variable,
            "source": source,
            "weighting": weighting,
            "n": 0,
            "mean": np.nan,
            "sd": np.nan,
            "mean_minus_sd": np.nan,
            "mean_plus_sd": np.nan,
            "minimum": np.nan,
            "maximum": np.nan,
        }
    mean = float(np.mean(array))
    sd = float(np.std(array, ddof=0))
    return {
        "variable": variable,
        "source": source,
        "weighting": weighting,
        "n": int(array.size),
        "mean": mean,
        "sd": sd,
        "mean_minus_sd": mean - sd,
        "mean_plus_sd": mean + sd,
        "minimum": float(np.min(array)),
        "maximum": float(np.max(array)),
    }


def _equal_year_background_stats(yearly_stats: pd.DataFrame) -> dict[str, object]:
    """用全概率方差公式汇总等年份权重的 LAI 背景均值与总体 SD。"""
    if yearly_stats.empty:
        return _stats_row("LAI", "study_area_background", np.asarray([]), "equal pre-event year weights")
    mean = float(yearly_stats["mean"].mean())
    second_moment = float((yearly_stats["variance_population"] + yearly_stats["mean"] ** 2).mean())
    sd = float(np.sqrt(max(second_moment - mean**2, 0.0)))
    return {
        "variable": "LAI",
        "source": "study_area_background",
        "weighting": "each pre-event year has equal weight",
        "n": int(yearly_stats["n_pixels"].sum()),
        "n_years": int(yearly_stats["lai_year"].nunique()),
        "mean": mean,
        "sd": sd,
        "mean_minus_sd": mean - sd,
        "mean_plus_sd": mean + sd,
        "minimum": float(yearly_stats["minimum"].min()),
        "maximum": float(yearly_stats["maximum"].max()),
    }


def _assign_bins(
    values: pd.Series,
    edges: np.ndarray,
    labels: list[str],
) -> pd.Categorical:
    """使用统一边界给事件级变量分箱。"""
    return pd.cut(
        pd.to_numeric(values, errors="coerce"),
        bins=edges,
        labels=labels,
        include_lowest=True,
        right=False,
    )


def _event_frequency_table(
    df: pd.DataFrame,
    value_col: str,
    bin_col: str,
    bin_order_col: str,
    group_cols: list[str] | None = None,
) -> pd.DataFrame:
    """按滑坡斑块数量计算频率，每个滑坡具有相同统计权重。"""
    group_cols = group_cols or []
    valid = df.dropna(subset=[value_col, bin_col, bin_order_col]).copy()
    if valid.empty:
        return pd.DataFrame()

    grouped = (
        valid.groupby(group_cols + [bin_order_col, bin_col], observed=True)
        .agg(
            n_landslides=("event_id", "nunique"),
            area_sum_m2=("area_m2", "sum"),
            value_mean=(value_col, "mean"),
            value_median=(value_col, "median"),
        )
        .reset_index()
    )
    if group_cols:
        totals = (
            valid.groupby(group_cols, observed=True)["event_id"]
            .nunique()
            .reset_index(name="denominator_landslides")
        )
        grouped = grouped.merge(totals, on=group_cols, how="left")
    else:
        grouped["denominator_landslides"] = int(valid["event_id"].nunique())
    grouped["landslide_frequency_percent"] = (
        grouped["n_landslides"] / grouped["denominator_landslides"] * 100.0
    )
    return grouped.sort_values(group_cols + [bin_order_col]).reset_index(drop=True)


def _read_study_area_values(raster_path: Path) -> np.ndarray:
    """读取研究区边界内的有效栅格像元，不读取研究区外的大幅影像。"""
    if not raster_path.exists():
        raise FileNotFoundError(f"Raster not found: {raster_path}")
    if not STUDY_AREA_PATH.exists():
        raise FileNotFoundError(f"Study area not found: {STUDY_AREA_PATH}")

    with rasterio.open(raster_path) as src:
        study = gpd.read_file(STUDY_AREA_PATH).to_crs(src.crs)
        geometries = [geom.__geo_interface__ for geom in study.geometry if geom is not None and not geom.is_empty]
        if not geometries:
            raise ValueError(f"No valid geometry in {STUDY_AREA_PATH}")
        clipped, _ = mask(src, geometries, crop=True, filled=False, indexes=1)
        values = np.asarray(clipped.compressed(), dtype=np.float64)

    return values[np.isfinite(values)]


def _find_lai_raster(year: int) -> Path:
    """按年份定位唯一一幅 Sentinel-2 LAI 栅格。"""
    matches = sorted(LAI_RASTER_DIR.glob(f"LAI_{int(year)}????_*_*_*_S2*_10m.tif"))
    if not matches:
        raise FileNotFoundError(f"No LAI raster found for {year} in {LAI_RASTER_DIR}")
    if len(matches) > 1:
        raise ValueError(f"Multiple LAI rasters found for {year}: {matches}")
    return matches[0]


def load_events() -> gpd.GeoDataFrame:
    """读取滑坡事件并生成地图坐标与面积类别。"""
    if not EVENTS_PATH.exists():
        raise FileNotFoundError(f"Events file not found: {EVENTS_PATH}")
    events = gpd.read_file(EVENTS_PATH)
    if events.empty:
        raise ValueError(f"No landslide events in {EVENTS_PATH}")

    events["event_id"] = events["event_id"].astype(str)
    events["event_year"] = pd.to_numeric(events["event_year"], errors="coerce").astype("Int64")
    events["area_m2"] = pd.to_numeric(events["area_m2"], errors="coerce")
    events["size_class"] = events["area_m2"].map(_size_class)
    centroids = events.geometry.centroid
    events["centroid_x"] = centroids.x
    events["centroid_y"] = centroids.y
    return events


def load_pre_event_lai() -> pd.DataFrame:
    """从面板缓存提取每个滑坡 core 在灾前 t-1 的 LAI 均值。"""
    if not PANEL_PATH.exists():
        raise FileNotFoundError(f"Panel file not found: {PANEL_PATH}")
    usecols = [
        "outcome",
        "year",
        "event_id",
        "zone_name",
        "zone_role",
        "event_year",
        "relative_year",
        "mean",
        "n_pixels",
    ]
    chunks: list[pd.DataFrame] = []
    for chunk in pd.read_csv(PANEL_PATH, usecols=usecols, chunksize=500_000):
        relative_year = pd.to_numeric(chunk["relative_year"], errors="coerce")
        selected = chunk[
            (chunk["outcome"].astype(str) == "LAI_SR2")
            & (chunk["zone_name"].astype(str) == "core")
            & (chunk["zone_role"].astype(str) == "treated")
            & (relative_year == -1)
        ].copy()
        if not selected.empty:
            chunks.append(selected)

    if not chunks:
        return pd.DataFrame(columns=["event_id", "lai_year", "pre_lai_mean", "pre_lai_n_pixels"])

    lai = pd.concat(chunks, ignore_index=True)
    lai["mean"] = pd.to_numeric(lai["mean"], errors="coerce")
    lai["n_pixels"] = pd.to_numeric(lai["n_pixels"], errors="coerce")
    lai["year"] = pd.to_numeric(lai["year"], errors="coerce")
    result = (
        lai.dropna(subset=["event_id", "mean"])
        .groupby("event_id", as_index=False)
        .agg(
            lai_year=("year", "first"),
            pre_lai_mean=("mean", "mean"),
            pre_lai_n_pixels=("n_pixels", "sum"),
        )
    )
    result["event_id"] = result["event_id"].astype(str)
    return result


def load_slope_features() -> pd.DataFrame:
    """读取每个滑坡的平均坡度，与恢复分析保持同一特征口径。"""
    source = FEATURE_PATH if FEATURE_PATH.exists() else SOURCE_DIR / "Fig04_event_level_values.csv"
    if not source.exists():
        raise FileNotFoundError(f"Slope feature file not found: {source}")
    header = pd.read_csv(source, nrows=0).columns
    usecols = [col for col in ["event_id", "slope_mean", "slope_std", "n_feature_pixels"] if col in header]
    feature = pd.read_csv(source, usecols=usecols)
    feature["event_id"] = feature["event_id"].astype(str)
    for column in ["slope_mean", "slope_std", "n_feature_pixels"]:
        if column in feature.columns:
            feature[column] = pd.to_numeric(feature[column], errors="coerce")
    return feature.drop_duplicates("event_id")


def add_distribution_bins(df: pd.DataFrame) -> pd.DataFrame:
    """给滑坡级 LAI 和坡度添加论文使用的统一分箱。"""
    result = df.copy()
    lai_labels = _lai_labels()
    result["pre_lai_bin"] = _assign_bins(result["pre_lai_mean"], LAI_BIN_EDGES, lai_labels)
    result["pre_lai_bin_order"] = result["pre_lai_bin"].map({label: i for i, label in enumerate(lai_labels)})
    result["pre_lai_bin_left"] = result["pre_lai_bin_order"].map(
        {i: LAI_BIN_EDGES[i] for i in range(len(lai_labels))}
    )
    result["pre_lai_bin_right"] = result["pre_lai_bin_order"].map(
        {i: LAI_BIN_EDGES[i + 1] for i in range(len(lai_labels))}
    )

    result["slope_bin"] = _assign_bins(result["slope_mean"], SLOPE_BIN_EDGES, SLOPE_BIN_LABELS)
    result["slope_bin_order"] = result["slope_bin"].map(
        {label: i for i, label in enumerate(SLOPE_BIN_LABELS)}
    )
    result["slope_bin_left_deg"] = result["slope_bin_order"].map(
        {i: SLOPE_BIN_EDGES[i] for i in range(len(SLOPE_BIN_LABELS))}
    )
    result["slope_bin_right_deg"] = result["slope_bin_order"].map(
        {i: SLOPE_BIN_EDGES[i + 1] for i in range(len(SLOPE_BIN_LABELS))}
    )
    return result


def build_lai_background(base: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """按灾前年份计算研究区 LAI 背景，各年份归一化后等权平均。"""
    lai_labels = _lai_labels()
    event_years = sorted(
        pd.to_numeric(
            base.loc[base["pre_lai_mean"].notna(), "lai_year"],
            errors="coerce",
        )
        .dropna()
        .astype(int)
        .unique()
        .tolist()
    )
    yearly_rows: list[dict[str, object]] = []
    yearly_stats_rows: list[dict[str, object]] = []
    for year in event_years:
        raster_path = _find_lai_raster(year)
        values = _read_study_area_values(raster_path)
        values = values[(values >= LAI_BIN_EDGES[0]) & (values < LAI_BIN_EDGES[-1])]
        yearly_stats_rows.append(
            {
                "lai_year": year,
                "n_pixels": int(values.size),
                "mean": float(np.mean(values)),
                "variance_population": float(np.var(values, ddof=0)),
                "sd": float(np.std(values, ddof=0)),
                "minimum": float(np.min(values)),
                "maximum": float(np.max(values)),
                "raster_path": str(raster_path),
            }
        )
        counts, _ = np.histogram(values, bins=LAI_BIN_EDGES)
        denominator = int(counts.sum())
        for order, (label, count) in enumerate(zip(lai_labels, counts)):
            yearly_rows.append(
                {
                    "lai_year": year,
                    "bin_order": order,
                    "pre_lai_bin": label,
                    "study_area_pixel_count": int(count),
                    "study_area_valid_pixels": denominator,
                    "study_area_frequency_percent": (float(count) / denominator * 100.0) if denominator else np.nan,
                    "raster_path": str(raster_path),
                }
            )

    yearly = pd.DataFrame(yearly_rows)
    if yearly.empty:
        return yearly, yearly, pd.DataFrame(yearly_stats_rows)
    summary = (
        yearly.groupby(["bin_order", "pre_lai_bin"], observed=True, as_index=False)
        .agg(
            study_area_frequency_percent=("study_area_frequency_percent", "mean"),
            n_background_years=("lai_year", "nunique"),
            study_area_pixel_count_sum=("study_area_pixel_count", "sum"),
            study_area_valid_pixels_sum=("study_area_valid_pixels", "sum"),
        )
    )
    return (
        yearly.sort_values(["lai_year", "bin_order"]),
        summary.sort_values("bin_order"),
        pd.DataFrame(yearly_stats_rows).sort_values("lai_year"),
    )


def build_slope_background() -> tuple[pd.DataFrame, np.ndarray]:
    """计算江湾镇全部有效坡度像元在四个坡度等级中的面积占比。"""
    values = _read_study_area_values(SLOPE_RASTER_PATH)
    values = values[(values >= SLOPE_BIN_EDGES[0]) & (values < SLOPE_BIN_EDGES[-1])]
    counts, _ = np.histogram(values, bins=SLOPE_BIN_EDGES)
    denominator = int(counts.sum())
    table = pd.DataFrame(
        {
            "bin_order": np.arange(len(SLOPE_BIN_LABELS), dtype=int),
            "slope_bin": SLOPE_BIN_LABELS,
            "study_area_pixel_count": counts.astype(int),
            "study_area_valid_pixels": denominator,
            "study_area_frequency_percent": np.where(
                denominator > 0,
                counts.astype(float) / denominator * 100.0,
                np.nan,
            ),
        }
    )
    return table, values


def _overlay_table(
    event_frequency: pd.DataFrame,
    background_frequency: pd.DataFrame,
    bin_col: str,
    event_order_col: str,
) -> pd.DataFrame:
    """合并研究区背景与滑坡频率，形成可直接用于 Origin 的宽表。"""
    event = event_frequency.rename(columns={event_order_col: "bin_order"}).copy()
    keep_event = [
        "bin_order",
        bin_col,
        "n_landslides",
        "denominator_landslides",
        "landslide_frequency_percent",
        "area_sum_m2",
        "value_mean",
        "value_median",
    ]
    event = event[[column for column in keep_event if column in event.columns]]
    background = background_frequency.copy()
    result = background.merge(event, on=["bin_order", bin_col], how="outer")
    return result.sort_values("bin_order").reset_index(drop=True)


def _attach_overlay_stats(
    table: pd.DataFrame,
    statistics: pd.DataFrame,
    variable: str,
) -> pd.DataFrame:
    """把背景与滑坡的总体统计量附加到频率表，方便 Origin 直接调用。"""
    result = table.copy()
    variable_stats = statistics[statistics["variable"] == variable]
    for source, prefix in [
        ("study_area_background", "background"),
        ("landslide_polygons", "landslide"),
    ]:
        selected = variable_stats[variable_stats["source"] == source]
        if selected.empty:
            continue
        row = selected.iloc[0]
        for column in ["n", "mean", "sd", "mean_minus_sd", "mean_plus_sd", "minimum", "maximum"]:
            result[f"{prefix}_{column}"] = row.get(column, np.nan)
    return result


def _add_origin_grouped_bar_coordinates(table: pd.DataFrame, bin_column: str) -> pd.DataFrame:
    """增加 Origin 分组柱状图坐标，使柱宽、组距和刻度中心可独立控制。"""
    result = table.copy().sort_values("bin_order").reset_index(drop=True)
    # 相邻组中心间距为1；两柱中心偏移0.18，推荐柱宽0.34，组间净空约0.30。
    result["tick_x"] = np.arange(1, len(result) + 1, dtype=float)
    result["background_bar_x"] = result["tick_x"] - 0.18
    result["landslide_bar_x"] = result["tick_x"] + 0.18
    result["recommended_bar_width_x"] = 0.34
    result["tick_label"] = result[bin_column].astype(str).str.replace(" deg", "", regex=False)
    return result


def export_workbook(path: Path, sheets: dict[str, pd.DataFrame]) -> None:
    """把多张规范化数据表写入一个 Excel 工作簿。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            for sheet_name, table in sheets.items():
                table.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    except PermissionError:
        # Excel/Origin 占用旧工作簿时不中断全部导出，另存一份本次更新结果。
        fallback = path.with_name(f"{path.stem}_updated{path.suffix}")
        try:
            with pd.ExcelWriter(fallback, engine="openpyxl") as writer:
                for sheet_name, table in sheets.items():
                    table.to_excel(writer, sheet_name=sheet_name[:31], index=False)
            print(f"[warning] workbook is locked; wrote: {fallback}")
        except PermissionError:
            print(f"[warning] skipped locked workbooks: {path.name}, {fallback.name}")


def write_csv(path: Path, table: pd.DataFrame) -> Path:
    """写出 CSV；文件被 Origin 占用时自动另存为 updated 版本。"""
    try:
        table.to_csv(path, index=False, encoding="utf-8-sig")
        return path
    except PermissionError:
        fallback = path.with_name(f"{path.stem}_updated{path.suffix}")
        table.to_csv(fallback, index=False, encoding="utf-8-sig")
        print(f"[warning] CSV is locked; wrote: {fallback}")
        return fallback


def main() -> None:
    """生成 Fig.4 地图属性、背景分布和滑坡叠置分布数据。"""
    SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    events = load_events()
    pre_lai = load_pre_event_lai()
    slope = load_slope_features()

    base = (
        events.drop(columns="geometry")
        .merge(pre_lai, on="event_id", how="left")
        .merge(slope, on="event_id", how="left")
    )
    base = add_distribution_bins(base)

    lai_event_all = _event_frequency_table(
        base,
        "pre_lai_mean",
        "pre_lai_bin",
        "pre_lai_bin_order",
    )
    lai_event_year = _event_frequency_table(
        base,
        "pre_lai_mean",
        "pre_lai_bin",
        "pre_lai_bin_order",
        ["event_year"],
    )
    slope_event_all = _event_frequency_table(
        base,
        "slope_mean",
        "slope_bin",
        "slope_bin_order",
    )
    slope_event_year = _event_frequency_table(
        base,
        "slope_mean",
        "slope_bin",
        "slope_bin_order",
        ["event_year"],
    )

    lai_background_year, lai_background_all, lai_background_year_stats = build_lai_background(base)
    slope_background_all, slope_background_values = build_slope_background()
    descriptive_statistics = pd.DataFrame(
        [
            _equal_year_background_stats(lai_background_year_stats),
            _stats_row(
                "LAI",
                "landslide_polygons",
                base["pre_lai_mean"],
                "one equal-weight observation per landslide polygon",
            ),
            _stats_row(
                "Slope",
                "study_area_background",
                slope_background_values,
                "one equal-weight valid 10 m study-area pixel",
            ),
            _stats_row(
                "Slope",
                "landslide_polygons",
                base["slope_mean"],
                "one equal-weight observation per landslide polygon",
            ),
        ]
    )
    lai_overlay = _overlay_table(lai_event_all, lai_background_all, "pre_lai_bin", "pre_lai_bin_order")
    slope_overlay = _overlay_table(slope_event_all, slope_background_all, "slope_bin", "slope_bin_order")
    lai_overlay = _attach_overlay_stats(lai_overlay, descriptive_statistics, "LAI")
    slope_overlay = _attach_overlay_stats(slope_overlay, descriptive_statistics, "Slope")
    lai_overlay = _add_origin_grouped_bar_coordinates(lai_overlay, "pre_lai_bin")
    slope_overlay = _add_origin_grouped_bar_coordinates(slope_overlay, "slope_bin")

    readme = pd.DataFrame(
        [
            {"item": "landslide_statistical_unit", "value": "one landslide polygon / event"},
            {"item": "study_area_statistical_unit", "value": "one valid 10 m pixel; pixel share equals area share"},
            {"item": "pre_event_lai", "value": "core mean at relative_year=-1 for each event"},
            {"item": "lai_background", "value": "study-area pixel distributions for matching pre-event years, normalized yearly and averaged with equal year weights"},
            {"item": "slope_background", "value": "all valid study-area slope pixels"},
            {"item": "slope_bins", "value": "0-10, 10-20, 20-30, >30 degrees"},
            {"item": "area_size_threshold", "value": "small <1000 m2; large >=1000 m2"},
            {"item": "events_source", "value": str(EVENTS_PATH)},
            {"item": "panel_source", "value": str(PANEL_PATH)},
            {"item": "slope_raster_source", "value": str(SLOPE_RASTER_PATH)},
            {"item": "study_area_source", "value": str(STUDY_AREA_PATH)},
        ]
    )

    map_cols = [
        "event_id",
        "event_year",
        "period",
        "area_m2",
        "size_class",
        "centroid_x",
        "centroid_y",
        "lai_year",
        "pre_lai_mean",
        "slope_mean",
        "slope_bin",
    ]
    map_table = base[[column for column in map_cols if column in base.columns]].copy()
    lai_event_values = base[
        ["event_id", "event_year", "area_m2", "size_class", "lai_year", "pre_lai_mean", "pre_lai_bin", "pre_lai_bin_order"]
    ].copy()
    slope_event_values = base[
        [
            "event_id",
            "event_year",
            "area_m2",
            "size_class",
            "slope_mean",
            "slope_std",
            "slope_bin",
            "slope_bin_left_deg",
            "slope_bin_right_deg",
            "slope_bin_order",
        ]
    ].copy()

    export_workbook(
        SOURCE_DIR / "Fig04A_Map_Landslide_Events.xlsx",
        {"map_event_points": map_table, "README": readme},
    )
    export_workbook(
        SOURCE_DIR / "Fig04B_PreEvent_LAI_Distribution.xlsx",
        {
            "overlay_frequency": lai_overlay,
            "landslide_event_values": lai_event_values,
            "landslide_frequency": lai_event_all,
            "landslide_freq_by_year": lai_event_year,
            "study_area_frequency": lai_background_all,
            "study_area_freq_by_year": lai_background_year,
            "study_area_year_stats": lai_background_year_stats,
            "descriptive_statistics": descriptive_statistics[descriptive_statistics["variable"] == "LAI"],
            "README": readme,
        },
    )
    export_workbook(
        SOURCE_DIR / "Fig04C_Slope_Distribution.xlsx",
        {
            "overlay_frequency": slope_overlay,
            "landslide_event_values": slope_event_values,
            "landslide_frequency": slope_event_all,
            "landslide_freq_by_year": slope_event_year,
            "study_area_frequency": slope_background_all,
            "descriptive_statistics": descriptive_statistics[descriptive_statistics["variable"] == "Slope"],
            "README": readme,
        },
    )
    export_workbook(
        SOURCE_DIR / "Fig04_All_SourceData.xlsx",
        {
            "map_event_points": map_table,
            "lai_overlay_frequency": lai_overlay,
            "lai_event_values": lai_event_values,
            "lai_study_area_by_year": lai_background_year,
            "lai_background_year_stats": lai_background_year_stats,
            "slope_overlay_frequency": slope_overlay,
            "slope_event_values": slope_event_values,
            "descriptive_statistics": descriptive_statistics,
            "README": readme,
        },
    )

    write_csv(SOURCE_DIR / "Fig04B_PreEvent_LAI_OverlayFrequency.csv", lai_overlay)
    write_csv(SOURCE_DIR / "Fig04C_Slope_OverlayFrequency.csv", slope_overlay)
    write_csv(SOURCE_DIR / "Fig04BC_Descriptive_Statistics.csv", descriptive_statistics)
    write_csv(SOURCE_DIR / "Fig04_event_level_values.csv", base)

    manifest = pd.DataFrame(
        [
            {"figure": "Fig04A", "file": str(SOURCE_DIR / "Fig04A_Map_Landslide_Events.xlsx"), "description": "landslide map attributes"},
            {"figure": "Fig04B", "file": str(SOURCE_DIR / "Fig04B_PreEvent_LAI_Distribution.xlsx"), "description": "landslide and study-area pre-event LAI distributions"},
            {"figure": "Fig04C", "file": str(SOURCE_DIR / "Fig04C_Slope_Distribution.xlsx"), "description": "landslide and study-area slope distributions"},
            {"figure": "Fig04", "file": str(SOURCE_DIR / "Fig04_All_SourceData.xlsx"), "description": "all Fig.4 source sheets"},
        ]
    )
    write_csv(SOURCE_DIR / "Fig04_manifest.csv", manifest)

    print(f"[done] Fig.4 source data folder: {SOURCE_DIR}")
    print(f"[done] landslide events: {len(base)}")
    print(f"[done] pre-event LAI available: {int(base['pre_lai_mean'].notna().sum())}")
    print(f"[done] slope available: {int(base['slope_mean'].notna().sum())}")
    print(f"[done] LAI background years: {sorted(lai_background_year['lai_year'].dropna().unique().tolist())}")
    print(f"[done] slope background valid pixels: {int(slope_background_all['study_area_valid_pixels'].max())}")


if __name__ == "__main__":
    main()
