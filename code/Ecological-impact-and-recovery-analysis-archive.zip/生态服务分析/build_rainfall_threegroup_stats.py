r"""生成研究区降雨三组比较数据与草图。

统计组：
1. 历史4月：2018-2023年及2025年4月的逐日区域平均降雨；
2. 2024年非4月：2024年除4月以外日期的逐日区域平均降雨；
3. 2024年4月：2024年4月的逐日区域平均降雨。

柱高为均值，误差棒为基于标准误计算的95%置信区间。组间比较采用
Welch t检验，并使用Holm方法校正两次比较的P值。脚本只读取已经提取
完成的逐日降雨缓存，不重复读取原始栅格。
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from scipy import stats


ROOT = Path(r"E:\python_base\Slide_dect")
DAILY_CACHE = (
    ROOT
    / "Output"
    / "EcoService_DID"
    / "04_did_results"
    / "Figure01_Rainfall_Daily_Jiangwan_2018_2025.csv"
)
OUTPUT_DIR = (
    ROOT
    / "Output"
    / "EcoService_DID"
    / "06_figure_source_data"
    / "Fig01_StudyArea"
    / "RainfallInset"
)
FIGURE_PATH = (
    ROOT
    / "Output"
    / "EcoService_DID"
    / "05_figures"
    / "Figure01_Rainfall_IndependentGroups_95CI_Preview.png"
)

HISTORICAL_YEARS = (2018, 2019, 2020, 2021, 2022, 2023, 2025)
GROUP_ORDER = ("Historical April", "2024 April", "2024 non-April")
GROUP_COLORS = {
    "Historical April": "#9AA5B1",
    "2024 non-April": "#4C78A8",
    "2024 April": "#D55E00",
}


def _holm_adjust(p_values: list[float]) -> list[float]:
    """对少量成对检验执行Holm逐步校正。"""

    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype="float64")
    running_max = 0.0
    count = len(p_values)
    for rank, original_index in enumerate(order):
        corrected = min(1.0, (count - rank) * p_values[original_index])
        running_max = max(running_max, corrected)
        adjusted[original_index] = running_max
    return adjusted.tolist()


def _p_to_symbol(p_value: float) -> str:
    """把校正后的P值转换为常用显著性标记。"""

    if p_value < 0.001:
        return "***"
    if p_value < 0.01:
        return "**"
    if p_value < 0.05:
        return "*"
    return "ns"


def build_plot_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """读取逐日缓存，生成原始长表、汇总表和显著性检验表。"""

    if not DAILY_CACHE.exists():
        raise FileNotFoundError(f"逐日降雨缓存不存在：{DAILY_CACHE}")

    daily = pd.read_csv(DAILY_CACHE)
    required = {"date", "year", "month", "daily_precipitation_mm"}
    missing = required.difference(daily.columns)
    if missing:
        raise ValueError(f"逐日降雨缓存缺少字段：{sorted(missing)}")

    daily["daily_precipitation_mm"] = pd.to_numeric(
        daily["daily_precipitation_mm"], errors="coerce"
    )
    daily = daily[np.isfinite(daily["daily_precipitation_mm"])].copy()

    parts: list[pd.DataFrame] = []
    selections = (
        (
            "Historical April",
            daily["year"].isin(HISTORICAL_YEARS) & daily["month"].eq(4),
        ),
        (
            "2024 non-April",
            daily["year"].eq(2024) & ~daily["month"].eq(4),
        ),
        ("2024 April", daily["year"].eq(2024) & daily["month"].eq(4)),
    )
    for group, mask in selections:
        part = daily.loc[
            mask, ["date", "year", "month", "daily_precipitation_mm"]
        ].copy()
        part.insert(0, "group", group)
        parts.append(part)

    raw = pd.concat(parts, ignore_index=True)
    raw["group_order"] = raw["group"].map(
        {group: index + 1 for index, group in enumerate(GROUP_ORDER)}
    )
    raw = raw.sort_values(["group_order", "date"]).reset_index(drop=True)
    # 提前生成固定的横向抖动坐标，便于在Origin中直接叠加逐日散点。
    rng = np.random.default_rng(2024)
    raw["origin_x_jitter"] = (
        raw["group_order"].astype("float64")
        + rng.uniform(-0.20, 0.20, size=len(raw))
    )

    summary_rows: list[dict[str, float | int | str]] = []
    for group in GROUP_ORDER:
        values = raw.loc[
            raw["group"].eq(group), "daily_precipitation_mm"
        ].to_numpy(dtype="float64")
        n = int(values.size)
        mean = float(np.mean(values))
        sd = float(np.std(values, ddof=1))
        se = sd / math.sqrt(n)
        t_critical = float(stats.t.ppf(0.975, df=n - 1))
        margin = t_critical * se
        summary_rows.append(
            {
                "group": group,
                "group_order": GROUP_ORDER.index(group) + 1,
                "n_days": n,
                "mean_mm_per_day": mean,
                "sd_mm_per_day": sd,
                "se_mm_per_day": se,
                "ci95_lower_mm_per_day": mean - margin,
                "ci95_upper_mm_per_day": mean + margin,
                "ci95_minus": margin,
                "ci95_plus": margin,
            }
        )
    summary = pd.DataFrame(summary_rows)

    comparisons = (
        ("Historical April", "2024 April"),
        ("2024 non-April", "2024 April"),
    )
    test_rows: list[dict[str, float | int | str]] = []
    raw_p_values: list[float] = []
    for group_a, group_b in comparisons:
        values_a = raw.loc[
            raw["group"].eq(group_a), "daily_precipitation_mm"
        ].to_numpy(dtype="float64")
        values_b = raw.loc[
            raw["group"].eq(group_b), "daily_precipitation_mm"
        ].to_numpy(dtype="float64")
        result = stats.ttest_ind(values_a, values_b, equal_var=False)
        raw_p_values.append(float(result.pvalue))
        test_rows.append(
            {
                "group_a": group_a,
                "group_b": group_b,
                "n_a": int(values_a.size),
                "n_b": int(values_b.size),
                "mean_difference_b_minus_a": float(
                    np.mean(values_b) - np.mean(values_a)
                ),
                "welch_t": float(result.statistic),
                "p_raw": float(result.pvalue),
            }
        )

    adjusted = _holm_adjust(raw_p_values)
    for row, p_adjusted in zip(test_rows, adjusted):
        row["p_holm"] = p_adjusted
        row["significance"] = _p_to_symbol(p_adjusted)
    tests = pd.DataFrame(test_rows)
    return raw, summary, tests


def draw_preview(
    raw: pd.DataFrame, summary: pd.DataFrame, tests: pd.DataFrame
) -> None:
    """绘制空心柱、每日观测点、95%置信区间和显著性括号草图。"""

    def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
        """优先加载系统Arial字体，缺失时退回Pillow默认字体。"""

        font_name = "arialbd.ttf" if bold else "arial.ttf"
        candidates = (
            Path("C:/Windows/Fonts") / font_name,
            Path("C:/Windows/Fonts/msyhbd.ttc" if bold else "msyh.ttc"),
        )
        for candidate in candidates:
            if candidate.exists():
                return ImageFont.truetype(str(candidate), size=size)
        return ImageFont.load_default()

    width, height = 1800, 1250
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image, "RGBA")
    font_axis = load_font(36)
    font_tick = load_font(31)
    font_title = load_font(43, bold=True)
    font_star = load_font(40, bold=True)

    left, right, top, bottom = 190, 1680, 165, 1015
    plot_width = right - left
    plot_height = bottom - top
    x_positions = np.linspace(left + 260, right - 260, len(GROUP_ORDER))
    summary_index = summary.set_index("group")

    # 为避免极端逐日降雨值挤压柱体，草图仅显示到原始值的98%分位数。
    data_top = float(raw["daily_precipitation_mm"].quantile(0.98))
    ci_top = float(summary["ci95_upper_mm_per_day"].max())
    bracket_base = max(data_top, ci_top) * 1.08
    bracket_step = max(data_top, ci_top) * 0.12
    y_max = bracket_base + len(tests) * bracket_step + bracket_step * 0.7

    def y_pixel(value: float) -> float:
        """把降雨量映射到绘图区像素坐标。"""

        clipped = min(max(value, 0.0), y_max)
        return bottom - clipped / y_max * plot_height

    # 绘制水平网格、坐标轴和刻度。
    tick_step = 10.0
    tick_values = np.arange(0.0, y_max + tick_step, tick_step)
    for tick in tick_values:
        if tick > y_max:
            continue
        y = y_pixel(float(tick))
        draw.line((left, y, right, y), fill="#E4E7EB", width=2)
        label = f"{int(tick)}"
        bbox = draw.textbbox((0, 0), label, font=font_tick)
        draw.text(
            (left - 22 - (bbox[2] - bbox[0]), y - (bbox[3] - bbox[1]) / 2),
            label,
            fill="#222222",
            font=font_tick,
        )
    draw.line((left, top, left, bottom), fill="#111111", width=4)
    draw.line((left, bottom, right, bottom), fill="#111111", width=4)

    rng = np.random.default_rng(2024)
    bar_width = 260
    for x_value, group in zip(x_positions, GROUP_ORDER):
        row = summary_index.loc[group]
        color = GROUP_COLORS[group]
        mean_value = float(row["mean_mm_per_day"])
        bar_top = y_pixel(mean_value)

        # 空心柱便于同时展示单日观测点。
        draw.rectangle(
            (x_value - bar_width / 2, bar_top, x_value + bar_width / 2, bottom),
            fill=(255, 255, 255, 210),
            outline=color,
            width=6,
        )
        values = raw.loc[
            raw["group"].eq(group), "daily_precipitation_mm"
        ].to_numpy(dtype="float64")
        jitter = rng.uniform(-bar_width * 0.42, bar_width * 0.42, size=values.size)
        for value, dx in zip(values, jitter):
            if value > data_top:
                continue
            px, py = x_value + dx, y_pixel(float(value))
            draw.ellipse((px - 5, py - 5, px + 5, py + 5), fill=color + "62")

        # 95%置信区间误差棒以及均值点。
        low_y = y_pixel(float(row["ci95_lower_mm_per_day"]))
        high_y = y_pixel(float(row["ci95_upper_mm_per_day"]))
        draw.line((x_value, low_y, x_value, high_y), fill=color, width=6)
        draw.line((x_value - 34, low_y, x_value + 34, low_y), fill=color, width=6)
        draw.line((x_value - 34, high_y, x_value + 34, high_y), fill=color, width=6)
        mean_y = y_pixel(mean_value)
        draw.ellipse(
            (x_value - 11, mean_y - 11, x_value + 11, mean_y + 11),
            fill=color,
            outline="white",
            width=3,
        )

        label_bbox = draw.textbbox((0, 0), group, font=font_tick)
        draw.text(
            (x_value - (label_bbox[2] - label_bbox[0]) / 2, bottom + 28),
            group,
            fill="#222222",
            font=font_tick,
        )

    group_to_x = {group: x for group, x in zip(GROUP_ORDER, x_positions)}
    for index, test in tests.iterrows():
        x1 = group_to_x[str(test["group_a"])]
        x2 = group_to_x[str(test["group_b"])]
        y_value = bracket_base + index * bracket_step
        height_value = bracket_step * 0.28
        y0 = y_pixel(y_value)
        y1 = y_pixel(y_value + height_value)
        draw.line((x1, y0, x1, y1, x2, y1, x2, y0), fill="#222222", width=4)
        symbol = str(test["significance"])
        bbox = draw.textbbox((0, 0), symbol, font=font_star)
        draw.text(
            ((x1 + x2) / 2 - (bbox[2] - bbox[0]) / 2, y1 - 52),
            symbol,
            fill="#111111",
            font=font_star,
        )

    title = "Rainfall conditions in Jiangwan"
    title_bbox = draw.textbbox((0, 0), title, font=font_title)
    draw.text(
        ((width - (title_bbox[2] - title_bbox[0])) / 2, 48),
        title,
        fill="#111111",
        font=font_title,
    )
    y_title = "Daily precipitation (mm/day)"
    y_title_bbox = draw.textbbox((0, 0), y_title, font=font_axis)
    title_layer = Image.new(
        "RGBA",
        (y_title_bbox[2] - y_title_bbox[0] + 20, y_title_bbox[3] - y_title_bbox[1] + 20),
        (255, 255, 255, 0),
    )
    ImageDraw.Draw(title_layer).text((10, 5), y_title, fill="#111111", font=font_axis)
    title_layer = title_layer.rotate(90, expand=True)
    image.paste(title_layer, (35, int((height - title_layer.height) / 2)), title_layer)

    note = "Bars: mean; error bars: 95% CI; points: daily observations"
    draw.text((left, 1150), note, fill="#555555", font=load_font(25))
    FIGURE_PATH.parent.mkdir(parents=True, exist_ok=True)
    image.save(FIGURE_PATH, quality=95)


def main() -> None:
    """写出Origin可直接使用的数据表并生成草图。"""

    def write_csv_or_keep_open(data: pd.DataFrame, path: Path) -> None:
        """写出CSV；若文件正被Origin占用，则保留现有文件并继续运行。"""

        try:
            data.to_csv(path, index=False, encoding="utf-8-sig")
        except PermissionError:
            print(f"CSV正被Origin占用，保留现有文件：{path}")

    raw, summary, tests = build_plot_data()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    raw_path = OUTPUT_DIR / "Fig01_Rainfall_IndependentGroups_OriginPoints.csv"
    scatter_path = OUTPUT_DIR / "Fig01_Rainfall_IndependentGroups_OriginScatterWide.csv"
    summary_path = OUTPUT_DIR / "Fig01_Rainfall_IndependentGroups_Mean_95CI.csv"
    tests_path = OUTPUT_DIR / "Fig01_Rainfall_IndependentGroups_PairwiseTests.csv"

    # 把每组散点整理为相邻的X-Y列，Origin可自动识别三组独立散点。
    scatter_columns: dict[str, pd.Series] = {}
    for group in GROUP_ORDER:
        group_key = (
            group.lower()
            .replace(" ", "_")
            .replace("-", "_")
        )
        group_rows = raw.loc[raw["group"].eq(group)].reset_index(drop=True)
        scatter_columns[f"{group_key}_x_jitter"] = group_rows[
            "origin_x_jitter"
        ]
        scatter_columns[f"{group_key}_daily_precipitation_mm"] = group_rows[
            "daily_precipitation_mm"
        ]
    scatter_wide = pd.DataFrame(scatter_columns)

    write_csv_or_keep_open(raw, raw_path)
    write_csv_or_keep_open(scatter_wide, scatter_path)
    write_csv_or_keep_open(summary, summary_path)
    write_csv_or_keep_open(tests, tests_path)
    draw_preview(raw, summary, tests)

    print(summary.to_string(index=False))
    print("\nPairwise tests:")
    print(tests.to_string(index=False))
    print(f"\nRaw data: {raw_path}")
    print(f"Origin scatter: {scatter_path}")
    print(f"Summary: {summary_path}")
    print(f"Tests: {tests_path}")
    print(f"Preview: {FIGURE_PATH}")


if __name__ == "__main__":
    main()
