from __future__ import annotations

from pathlib import Path

from ecoservice_analysis.recovery_figures import build_fig06_fig07_outputs


# 输入数据：
# 1. E:/python_base/Slide_dect/Output/EcoService_DID/04_did_results/area_individual_att_percent.csv
# 2. E:/python_base/Slide_dect/Output/EcoService_DID/06_figure_source_data/Fig04_Landslide_Distribution/Fig04_event_level_values.csv
#
# 主要公式：
# ATT% = (observed - counterfactual) / counterfactual * 100
# 恢复到无滑坡反事实水平 90% 的判定：ATT% >= -10%
#
# 输出：
# 1. 规范 CSV：E:/python_base/Slide_dect/Output/EcoService_DID/04_did_results/fig06_*.csv 和 fig07_*.csv
# 2. 复刻用源数据：E:/python_base/Slide_dect/Output/EcoService_DID/06_figure_source_data/Fig06_Fig07_Recovery/
# 3. HTML 图：E:/python_base/Slide_dect/Output/EcoService_DID/05_figures/


PROJECT_ROOT = Path("E:/python_base/Slide_dect")
RESULTS_DIR = PROJECT_ROOT / "Output" / "EcoService_DID" / "04_did_results"
FIGURES_DIR = PROJECT_ROOT / "Output" / "EcoService_DID" / "05_figures"


def main() -> None:
    """只重建 Fig.6 和 Fig.7 的恢复统计表和 HTML 图，不重新提取栅格。"""
    outputs = build_fig06_fig07_outputs(RESULTS_DIR, FIGURES_DIR)
    print("[done] written tables:")
    for path in outputs["written_tables"]:
        print(f"  {path}")
    print("[done] written figures:")
    for path in outputs["figures"]:
        print(f"  {path}")


if __name__ == "__main__":
    main()
