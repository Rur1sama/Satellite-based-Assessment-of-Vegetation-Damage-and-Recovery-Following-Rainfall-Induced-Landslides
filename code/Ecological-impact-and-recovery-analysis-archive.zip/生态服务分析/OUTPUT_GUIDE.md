# EcoService DID 输出说明

## 主流程命令

只基于现有 CSV 缓存更新结果图：

```powershell
python E:\python_base\Slide_dect\代码\生态服务分析\run_pipeline.py --config E:\python_base\Slide_dect\代码\生态服务分析\config_example.json --steps plots
```

重新提取面板或重算 DID 时再使用：

```powershell
python E:\python_base\Slide_dect\代码\生态服务分析\run_pipeline.py --config E:\python_base\Slide_dect\代码\生态服务分析\config_example.json --steps panel did plots --force
```

只重建 Fig.6 和 Fig.7 恢复统计表与 HTML：

```powershell
python E:\python_base\Slide_dect\代码\生态服务分析\build_fig06_07_recovery_tables.py
```

## 当前主线图

图件目录：

```text
E:\python_base\Slide_dect\Output\EcoService_DID\05_figures
```

当前主线只保留这些图：

- `Dashboard_04_Landslide_Distribution_Patterns.html`：Fig.4，滑坡空间分布、灾前 LAI 分布频率、坡度 5 度分箱频率。
- `Dashboard_05_Effects_Event_Study.html`：Fig.5，滑坡对 FVC、LAI、GPP 的 DID ATT% 动态影响；两行分别为大小滑坡和中心-外围环带。
- `Dashboard_06A_Recovery_Time_Boxplots.html`：Fig.6A，按面积分箱和坡度分箱比较恢复到 50% 反事实水平所需时间。箱线图只绘制已恢复样本，并用叉号标记未恢复删失比例。
- `Dashboard_06B_Cumulative_Recovery_Curves.html`：Fig.6B，按面积分箱和坡度分箱绘制稳健均值恢复拟合曲线。每个相对年份先用 3 倍 IQR 去异常后计算 ATT% 均值，再用 t0-t5 六个时间节点拟合。
- `Dashboard_07_Cumulative_Recovery_Rate.html`：Fig.7，按小滑坡和大滑坡绘制稳健均值恢复拟合曲线。每个相对年份先用 3 倍 IQR 去异常后计算 ATT% 均值，再用 t0-t5 六个时间节点拟合。

FAPAR 不作为主结果展示，只作为 GPP 计算的中间指标。主结果顺序统一为 FVC、LAI、GPP。

## 当前关键结果表

结果表目录：

```text
E:\python_base\Slide_dect\Output\EcoService_DID\04_did_results
```

建议优先使用：

- `event_study_att_percent.csv`：Fig.5 的总体百分比事件研究 ATT。
- `core_size_event_study_att_percent.csv`：Fig.5 中大小滑坡分组的事件研究 ATT%。
- `area_individual_att_percent.csv`：Fig.6/Fig.7 的单滑坡 DID ATT% 时间序列缓存。
- `fig06_recovery_event_table.csv`：单滑坡恢复达标主表；恢复标准为 `ATT% >= -50`，即达到无滑坡反事实水平的 50%。
- `fig06_recovery_time_area_bin_summary.csv`：Fig.6A 面积分箱恢复时间统计。
- `fig06_recovery_time_slope_bin_summary.csv`：Fig.6A 坡度 5 度分箱恢复时间统计。
- `fig06_mean_area_bin_trajectory.csv`：Fig.6B 面积分箱 3 倍 IQR 稳健均值 ATT% 时间节点。
- `fig06_mean_slope_bin_trajectory.csv`：Fig.6B 坡度 5 度分箱 3 倍 IQR 稳健均值 ATT% 时间节点。
- `fig06_mean_fit_area_bin_summary.csv`：Fig.6B 面积分箱稳健均值曲线达到 50% 恢复阈值的拟合时间。
- `fig06_mean_fit_slope_bin_summary.csv`：Fig.6B 坡度分箱稳健均值曲线达到 50% 恢复阈值的拟合时间。
- `fig07_mean_size_trajectory.csv`：Fig.7 小滑坡和大滑坡 3 倍 IQR 稳健均值 ATT% 时间节点。
- `fig07_mean_fit_size_summary.csv`：Fig.7 小滑坡和大滑坡稳健均值曲线达到 50% 恢复阈值的拟合时间。
- `fig06_cumulative_area_bin_share.csv`、`fig06_cumulative_slope_bin_share.csv`、`fig07_cumulative_size_share.csv`：保留为对象数量口径的累计恢复比例备份表，当前 Fig.6B/Fig.7 不再直接使用。

归档源数据同步输出到：

```text
E:\python_base\Slide_dect\Output\EcoService_DID\06_figure_source_data\Fig06_Fig07_Recovery
```

其中 `Fig06_Fig07_Recovery_SourceData.xlsx` 汇总了 Fig.6 和 Fig.7 的全部规范化源表。
