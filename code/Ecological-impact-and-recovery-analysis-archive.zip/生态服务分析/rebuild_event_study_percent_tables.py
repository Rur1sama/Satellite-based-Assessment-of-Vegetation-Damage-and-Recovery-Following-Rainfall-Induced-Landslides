"""Rebuild clean event-study percent tables for the paper workflow.

This script uses cached panel data only. It does not re-extract rasters.

Main outputs in 04_did_results:
- group_time_att.csv
- event_study_att.csv
- event_study_att_percent_zone_only.csv
- core_size_event_study_att_percent.csv
- event_study_att_percent.csv

The final event_study_att_percent.csv is a combined source table:
- comparison_type = "zone": core, ring_0_10m, ring_10_20m
- comparison_type = "size": core_size_small, core_size_large
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

import pandas as pd

from ecoservice_analysis.core_size import run_core_size_class_analysis
from ecoservice_analysis.did import estimate_staggered_did
from ecoservice_analysis.io_utils import ensure_dir, safe_to_csv, setup_logger
from ecoservice_analysis.summaries import summarize_percent_event_study, summarize_radiation_range


PROJECT_ROOT = Path(r"E:\python_base\Slide_dect")
CODE_DIR = PROJECT_ROOT / "代码" / "生态服务分析"
CONFIG_PATH = CODE_DIR / "config_example.json"


def load_config() -> dict:
    """Load the active ecosystem-service analysis config."""
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def enabled_outcomes(cfg: dict) -> list[str]:
    """Return outcomes enabled for the current paper figures."""
    return [name for name, spec in cfg.get("outcomes", {}).items() if bool(spec.get("enabled", False))]


def treated_zones(cfg: dict) -> list[str]:
    """Return the center/periphery zones used in the main event-study table."""
    zones = cfg.get("analysis_scope", {}).get("treated_zones", ["core", "ring_0_10m", "ring_10_20m"])
    if isinstance(zones, str):
        zones = [zones]
    return [str(zone) for zone in zones]


def filter_panel(panel: pd.DataFrame, outcomes: list[str], zones: list[str]) -> pd.DataFrame:
    """Keep enabled outcomes, requested treated zones, and never-control rows."""
    result = panel[panel["outcome"].astype(str).isin(outcomes)].copy()
    keep_zone = (result["zone_role"].astype(str) != "treated") | result["zone_name"].astype(str).isin(zones)
    return result[keep_zone].copy()


def add_common_source_columns(df: pd.DataFrame, comparison_type: str, source_table: str) -> pd.DataFrame:
    """Add columns that make the combined event-study table self-describing."""
    result = df.copy()
    result["comparison_type"] = comparison_type
    result["source_table"] = source_table
    if "original_zone_name" not in result.columns:
        result["original_zone_name"] = result.get("zone_name", "")
    if "series_name" not in result.columns:
        if comparison_type == "zone":
            result["series_name"] = result.get("zone_name", "")
        else:
            result["series_name"] = result.get("size_class", "")
    return result


def build_combined_percent_table(zone_percent: pd.DataFrame, size_percent: pd.DataFrame) -> pd.DataFrame:
    """Combine zone and size event-study percent rows into one clean source table."""
    zone_rows = add_common_source_columns(
        zone_percent,
        comparison_type="zone",
        source_table="event_study_att_percent_zone_only.csv",
    )
    zone_rows["size_class"] = zone_rows.get("size_class", pd.Series([""] * len(zone_rows))).fillna("")
    zone_rows["size_zone_name"] = zone_rows.get("size_zone_name", pd.Series([""] * len(zone_rows))).fillna("")

    size_rows = add_common_source_columns(
        size_percent,
        comparison_type="size",
        source_table="core_size_event_study_att_percent.csv",
    )
    if not size_rows.empty:
        size_rows["original_zone_name"] = size_rows.get("zone_name", "core")
        size_rows["series_name"] = size_rows["size_class"].astype(str)
        size_rows["zone_name"] = "core_size_" + size_rows["size_class"].astype(str)

    all_columns = list(dict.fromkeys(list(zone_rows.columns) + list(size_rows.columns)))
    combined = pd.concat(
        [zone_rows.reindex(columns=all_columns), size_rows.reindex(columns=all_columns)],
        ignore_index=True,
    )
    sort_cols = [col for col in ["comparison_type", "outcome", "zone_name", "size_class", "relative_year"] if col in combined.columns]
    return combined.sort_values(sort_cols).reset_index(drop=True)


def archive_unused_tables(results_dir: Path) -> Path:
    """Move clearly obsolete DID result tables into a timestamped archive folder."""
    archive_dir = results_dir / f"_archive_unused_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    patterns = [
        "geometry_inner_*",
        "large_high_recovery_*",
        "over_recovery_20000_50000_*",
        "recovery_outlier_*",
        "radiation_zone_post_mean_FAPAR.csv",
    ]
    files: list[Path] = []
    for pattern in patterns:
        files.extend(sorted(results_dir.glob(pattern)))

    files = [path for path in dict.fromkeys(files) if path.is_file()]
    temp_dirs = [path for path in [results_dir / "_core_size_class_tmp"] if path.exists() and path.is_dir()]
    if not files and not temp_dirs:
        return archive_dir

    root = results_dir.resolve()
    archive_dir.mkdir(parents=True, exist_ok=True)
    for path in files:
        src = path.resolve()
        if root not in src.parents:
            raise RuntimeError(f"Refusing to move file outside results dir: {src}")
        shutil.move(str(src), str(archive_dir / path.name))
    for path in temp_dirs:
        src = path.resolve()
        if root not in src.parents:
            raise RuntimeError(f"Refusing to move directory outside results dir: {src}")
        shutil.move(str(src), str(archive_dir / path.name))
    return archive_dir


def main() -> None:
    """Recompute DID percent tables and archive obsolete outputs."""
    cfg = load_config()
    did_cfg = cfg.get("did", {})
    results_dir = ensure_dir(Path(did_cfg["results_dir"]))
    panel_path = Path(cfg["panel"]["panel_output"])
    log = setup_logger(results_dir / "rebuild_event_study_percent_tables.log")

    outcomes = enabled_outcomes(cfg)
    zones = treated_zones(cfg)
    log.info("Enabled outcomes: %s", outcomes)
    log.info("Main treated zones: %s", zones)

    panel = pd.read_csv(panel_path)
    panel = filter_panel(panel, outcomes, zones)
    log.info("Filtered panel rows: %s", len(panel))

    group_time, event_study = estimate_staggered_did(
        panel=panel,
        results_dir=results_dir,
        value_column=did_cfg.get("value_column", "mean"),
        reference_relative_year=int(did_cfg.get("reference_relative_year", -1)),
        event_window=did_cfg.get("event_window", [-2, 5]),
        control_group=did_cfg.get("control_group", "not_yet_plus_never"),
        min_treated_units=int(did_cfg.get("min_treated_units", 1)),
        min_control_units=int(did_cfg.get("min_control_units", 1)),
        alpha=float(did_cfg.get("alpha", 0.05)),
        pretrend_match_never_control=bool(did_cfg.get("pretrend_match_never_control", False)),
        pretrend_match_threshold=float(did_cfg.get("pretrend_match_threshold", 0.1)),
        pretrend_match_source_zone=str(did_cfg.get("pretrend_match_source_zone", "core")),
        pretrend_match_min_years=int(did_cfg.get("pretrend_match_min_years", 1)),
        pretrend_match_empty_action=str(did_cfg.get("pretrend_match_empty_action", "nearest")),
        pretrend_match_nearest_fraction=float(did_cfg.get("pretrend_match_nearest_fraction", 0.05)),
        pretrend_match_nearest_min_units=int(did_cfg.get("pretrend_match_nearest_min_units", 20)),
        logger=log,
    )
    summarize_radiation_range(
        event_study=event_study,
        output_dir=results_dir,
        post_years=[int(x) for x in did_cfg.get("radiation_post_years", [0, 1, 2])],
        alpha=float(did_cfg.get("alpha", 0.05)),
    )
    zone_percent = summarize_percent_event_study(
        event_study=event_study,
        panel=panel,
        output_dir=results_dir,
        value_column=did_cfg.get("value_column", "mean"),
    )
    safe_to_csv(zone_percent, results_dir / "event_study_att_percent_zone_only.csv", index=False, encoding="utf-8-sig")

    core_size_outputs = run_core_size_class_analysis(
        panel=panel,
        results_dir=results_dir,
        outcome_cfgs=cfg.get("outcomes", {}),
        did_cfg=did_cfg,
        size_cfg=cfg.get("core_size_comparison", {}),
        logger=log,
    )
    size_percent = core_size_outputs.get("event_study_percent", pd.DataFrame())

    combined = build_combined_percent_table(zone_percent, size_percent)
    safe_to_csv(combined, results_dir / "event_study_att_percent.csv", index=False, encoding="utf-8-sig")

    manifest = pd.DataFrame(
        [
            {"file": "event_study_att_percent.csv", "description": "combined zone and size event-study ATT percent table"},
            {"file": "event_study_att_percent_zone_only.csv", "description": "zone-only table: core, ring_0_10m, ring_10_20m"},
            {"file": "core_size_event_study_att_percent.csv", "description": "size-only core table: small and large landslides"},
        ]
    )
    safe_to_csv(manifest, results_dir / "event_study_percent_manifest.csv", index=False, encoding="utf-8-sig")

    archive_dir = archive_unused_tables(results_dir)
    log.info("Archived obsolete tables under: %s", archive_dir if archive_dir.exists() else "none")

    print("[done] rebuilt event-study tables")
    print(f"[done] event_study rows: {len(event_study)}")
    print(f"[done] zone percent rows: {len(zone_percent)}")
    print(f"[done] size percent rows: {len(size_percent)}")
    print(f"[done] combined percent rows: {len(combined)}")
    print(f"[done] outputs: {results_dir}")
    if archive_dir.exists():
        print(f"[done] archived obsolete tables: {archive_dir}")


if __name__ == "__main__":
    main()
