r"""绘制江湾镇降雨三组比较的完整条件草图。

图中同时展示：
1. 三个互不重叠的降雨样本组；
2. 每日观测散点；
3. 均值空心柱和95%置信区间；
4. 断轴上方的极端日降雨；
5. Welch t检验经Holm校正后的显著性括号。
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(r"E:\python_base\Slide_dect")
DATA_DIR = (
    ROOT
    / "Output"
    / "EcoService_DID"
    / "06_figure_source_data"
    / "Fig01_StudyArea"
    / "RainfallInset"
)
RAW_PATH = DATA_DIR / "Fig01_Rainfall_IndependentGroups_OriginPoints.csv"
SUMMARY_PATH = DATA_DIR / "Fig01_Rainfall_IndependentGroups_Mean_95CI.csv"
TEST_PATH = DATA_DIR / "Fig01_Rainfall_IndependentGroups_PairwiseTests.csv"
OUTPUT_PATH = (
    ROOT
    / "Output"
    / "EcoService_DID"
    / "05_figures"
    / "Figure01_Rainfall_IndependentGroups_FullConditions_Preview.png"
)

GROUPS = ("Historical April", "2024 non-April", "2024 April")
COLORS = {
    "Historical April": "#7D8793",
    "2024 non-April": "#3F77A8",
    "2024 April": "#D95F02",
}


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    """加载系统字体，保证英文和数值标签清晰。"""

    name = "arialbd.ttf" if bold else "arial.ttf"
    path = Path("C:/Windows/Fonts") / name
    return ImageFont.truetype(str(path), size=size)


def _centered_text(
    draw: ImageDraw.ImageDraw,
    xy: tuple[float, float],
    text: str,
    font: ImageFont.FreeTypeFont,
    fill: str,
) -> None:
    """以给定坐标为中心绘制文字。"""

    box = draw.textbbox((0, 0), text, font=font)
    draw.text(
        (xy[0] - (box[2] - box[0]) / 2, xy[1] - (box[3] - box[1]) / 2),
        text,
        font=font,
        fill=fill,
    )


def main() -> None:
    """读取独立分组CSV并绘制带断轴的完整草图。"""

    raw = pd.read_csv(RAW_PATH)
    summary = pd.read_csv(SUMMARY_PATH).set_index("group")
    tests = pd.read_csv(TEST_PATH)

    width, height = 1800, 1320
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image, "RGBA")

    # 主图区显示0-70 mm/day；上方断轴区显示70-205 mm/day。
    left, right = 205, 1690
    upper_top, upper_bottom = 145, 335
    main_top, main_bottom = 415, 1050
    x_positions = np.array([455.0, 925.0, 1395.0])
    main_max = 70.0
    upper_min, upper_max = 70.0, 205.0

    def y_main(value: float) -> float:
        return main_bottom - value / main_max * (main_bottom - main_top)

    def y_upper(value: float) -> float:
        return upper_bottom - (value - upper_min) / (upper_max - upper_min) * (
            upper_bottom - upper_top
        )

    # 标题。
    _centered_text(
        draw,
        (width / 2, 65),
        "Rainfall conditions in Jiangwan",
        _font(43, True),
        "#111111",
    )

    # 绘制主图区网格和刻度。
    for tick in range(0, 71, 10):
        y = y_main(float(tick))
        draw.line((left, y, right, y), fill="#E1E5EA", width=2)
        draw.text((left - 78, y - 17), str(tick), font=_font(28), fill="#222222")
    draw.line((left, main_top, left, main_bottom), fill="#111111", width=4)
    draw.line((left, main_bottom, right, main_bottom), fill="#111111", width=4)

    # 绘制断轴图区及其刻度。
    for tick in (100, 150, 200):
        y = y_upper(float(tick))
        draw.line((left, y, right, y), fill="#EDF0F3", width=2)
        draw.text((left - 92, y - 17), str(tick), font=_font(28), fill="#222222")
    draw.line((left, upper_top, left, upper_bottom), fill="#111111", width=4)

    # 左轴断裂符号，明确70-205之间采用分段尺度。
    draw.line((left - 10, 365, left + 12, 382), fill="#111111", width=4)
    draw.line((left - 10, 385, left + 12, 402), fill="#111111", width=4)

    rng = np.random.default_rng(2024)
    bar_width = 245
    for x, group in zip(x_positions, GROUPS):
        row = summary.loc[group]
        color = COLORS[group]
        mean = float(row["mean_mm_per_day"])
        low = float(row["ci95_lower_mm_per_day"])
        high = float(row["ci95_upper_mm_per_day"])

        # 绘制空心均值柱。
        draw.rectangle(
            (x - bar_width / 2, y_main(mean), x + bar_width / 2, main_bottom),
            fill=(255, 255, 255, 205),
            outline=color,
            width=6,
        )

        values = raw.loc[
            raw["group"].eq(group), "daily_precipitation_mm"
        ].to_numpy(dtype="float64")
        jitter = rng.uniform(-bar_width * 0.43, bar_width * 0.43, values.size)
        for value, dx in zip(values, jitter):
            px = x + dx
            if value <= main_max:
                py = y_main(float(value))
            elif value >= upper_min:
                py = y_upper(float(value))
            else:
                continue
            draw.ellipse((px - 5, py - 5, px + 5, py + 5), fill=color + "66")

        # 绘制95%置信区间和均值点。
        draw.line((x, y_main(low), x, y_main(high)), fill=color, width=6)
        draw.line((x - 35, y_main(low), x + 35, y_main(low)), fill=color, width=6)
        draw.line((x - 35, y_main(high), x + 35, y_main(high)), fill=color, width=6)
        draw.ellipse(
            (x - 12, y_main(mean) - 12, x + 12, y_main(mean) + 12),
            fill=color,
            outline="white",
            width=3,
        )

        # 在横轴下方标注分组，在柱内标注均值和95%CI。
        _centered_text(draw, (x, 1100), group, _font(28), "#222222")
        ci_text = f"{mean:.2f} [{low:.2f}, {high:.2f}]"
        _centered_text(draw, (x, y_main(mean) - 32), ci_text, _font(21), color)

    # 显著性括号直接显示Holm校正P值。
    group_x = dict(zip(GROUPS, x_positions))
    bracket_levels = (55.0, 64.0)
    for row, level in zip(tests.to_dict("records"), bracket_levels):
        x1 = group_x[str(row["group_a"])]
        x2 = group_x[str(row["group_b"])]
        y0, y1 = y_main(level), y_main(level + 2.0)
        draw.line((x1, y0, x1, y1, x2, y1, x2, y0), fill="#222222", width=4)
        label = f"*  PHolm={float(row['p_holm']):.3f}"
        _centered_text(draw, ((x1 + x2) / 2, y1 - 22), label, _font(23, True), "#111111")

    # 纵轴标题。
    axis_text = "Daily precipitation (mm/day)"
    box = draw.textbbox((0, 0), axis_text, font=_font(31))
    layer = Image.new("RGBA", (box[2] - box[0] + 20, box[3] - box[1] + 20), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((10, 5), axis_text, font=_font(31), fill="#111111")
    layer = layer.rotate(90, expand=True)
    image.paste(layer, (32, int((height - layer.height) / 2)), layer)

    # 图下注明统计口径，避免把SD、SE和95%CI混淆。
    note = (
        "Bars: mean; error bars: 95% CI; points: daily observations; "
        "Welch's t-test with Holm correction"
    )
    draw.text((left, 1210), note, font=_font(24), fill="#4B5563")
    draw.text(
        (left, 1250),
        "Axis break retains extreme daily rainfall (maximum = 191.68 mm/day).",
        font=_font(22),
        fill="#6B7280",
    )

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUTPUT_PATH, quality=96)
    print(OUTPUT_PATH)


if __name__ == "__main__":
    main()
