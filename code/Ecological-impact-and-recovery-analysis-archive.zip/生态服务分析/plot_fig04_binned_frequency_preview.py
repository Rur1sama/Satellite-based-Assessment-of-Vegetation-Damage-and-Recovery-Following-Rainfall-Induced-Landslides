"""绘制 Fig.4 滑坡分布规律及研究区背景叠置分布。

灰色宽柱表示江湾镇研究区的像元面积占比，彩色窄柱表示滑坡斑块数量占比。
两个柱状图使用同一分箱和同一百分比纵轴，因此可以直接比较“环境供给背景”
与“滑坡出现频率”。
"""
from __future__ import annotations

from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from PIL import Image, ImageDraw, ImageFont


PROJECT_ROOT = Path(r"E:\python_base\Slide_dect")
OUTPUT_ROOT = PROJECT_ROOT / "Output" / "EcoService_DID"
SOURCE_DIR = OUTPUT_ROOT / "06_figure_source_data" / "Fig04_Landslide_Distribution"
FIGURES_DIR = OUTPUT_ROOT / "05_figures"

EVENTS_PATH = OUTPUT_ROOT / "01_landslide_events.gpkg"
STUDY_AREA_PATH = PROJECT_ROOT / "Input" / "Jiangwan" / "Jiangwan.shp"
LAI_CSV = SOURCE_DIR / "Fig04B_PreEvent_LAI_OverlayFrequency.csv"
SLOPE_CSV = SOURCE_DIR / "Fig04C_Slope_OverlayFrequency.csv"
OUT_HTML = SOURCE_DIR / "Fig04BC_Background_Overlay_Bar_Preview.html"
OUT_PNG = SOURCE_DIR / "Fig04BC_Background_Overlay_Bar_Preview.png"
OUT_DASHBOARD = FIGURES_DIR / "Dashboard_04_Landslide_Distribution_Patterns.html"

BACKGROUND_COLOR = "#d2d2d2"
LAI_COLOR = "#b2182b"
SLOPE_COLOR = "#2166ac"


def latest_available_csv(path: Path) -> Path:
    """Origin 占用正式 CSV 时，优先读取导出器生成的较新 updated 文件。"""
    updated = path.with_name(f"{path.stem}_updated{path.suffix}")
    candidates = [candidate for candidate in [path, updated] if candidate.exists()]
    if not candidates:
        return path
    return max(candidates, key=lambda candidate: candidate.stat().st_mtime)


def read_overlay_table(path: Path, bin_column: str) -> pd.DataFrame:
    """读取可直接叠置绘图的宽表，并确保分箱顺序稳定。"""
    if not path.exists():
        raise FileNotFoundError(f"Fig.4 overlay table not found: {path}")
    table = pd.read_csv(path)
    for column in ["bin_order", "study_area_frequency_percent", "landslide_frequency_percent"]:
        table[column] = pd.to_numeric(table[column], errors="coerce")
    table = table.dropna(subset=["bin_order", bin_column]).sort_values("bin_order").copy()
    table[bin_column] = table[bin_column].astype(str)
    return table


def _add_overlay_bars(
    fig: go.Figure,
    table: pd.DataFrame,
    bin_column: str,
    landslide_color: str,
    row: int,
    col: int,
    show_background_legend: bool,
    show_landslide_legend: bool,
    landslide_name: str,
) -> None:
    """先画研究区背景宽柱，再叠加滑坡频率窄柱。"""
    labels = table[bin_column].astype(str)
    fig.add_trace(
        go.Bar(
            x=labels,
            y=table["study_area_frequency_percent"],
            width=0.86,
            marker=dict(color=BACKGROUND_COLOR, line=dict(color="#8a8a8a", width=0.7)),
            name="Study-area background",
            legendgroup="background",
            showlegend=show_background_legend,
            customdata=np.stack(
                [
                    table["study_area_pixel_count_sum"]
                    if "study_area_pixel_count_sum" in table.columns
                    else table["study_area_pixel_count"],
                    table["study_area_valid_pixels_sum"]
                    if "study_area_valid_pixels_sum" in table.columns
                    else table["study_area_valid_pixels"],
                ],
                axis=-1,
            ),
            hovertemplate=(
                "Class=%{x}<br>Study-area share=%{y:.2f}%"
                "<br>pixel count=%{customdata[0]:,.0f}"
                "<br>valid pixels=%{customdata[1]:,.0f}<extra></extra>"
            ),
        ),
        row=row,
        col=col,
    )
    fig.add_trace(
        go.Bar(
            x=labels,
            y=table["landslide_frequency_percent"],
            width=0.48,
            marker=dict(color=landslide_color, line=dict(color="#222222", width=0.8)),
            name=landslide_name,
            legendgroup=landslide_name,
            showlegend=show_landslide_legend,
            customdata=np.stack(
                [table["n_landslides"], table["denominator_landslides"]],
                axis=-1,
            ),
            hovertemplate=(
                "Class=%{x}<br>Landslide share=%{y:.2f}%"
                "<br>landslides=%{customdata[0]:,.0f}/%{customdata[1]:,.0f}<extra></extra>"
            ),
        ),
        row=row,
        col=col,
    )


def _style_distribution_axes(fig: go.Figure, row: int, col: int, x_title: str) -> None:
    """统一两个频率子图的坐标轴格式。"""
    fig.update_xaxes(
        title_text=x_title,
        showline=True,
        mirror=True,
        ticks="outside",
        tickangle=0,
        row=row,
        col=col,
    )


def _add_statistics_annotation(fig: go.Figure, table: pd.DataFrame, row: int, col: int) -> None:
    """在频率图空白处标注背景与滑坡的 Mean、SD 和 Mean ± SD。"""
    first = table.iloc[0]

    def line(prefix: str, label: str) -> str:
        return (
            f"<b>{label}</b> n={int(first[f'{prefix}_n']):,}<br>"
            f"Mean={first[f'{prefix}_mean']:.2f}, SD={first[f'{prefix}_sd']:.2f}<br>"
            f"Mean ± SD=[{first[f'{prefix}_mean_minus_sd']:.2f}, "
            f"{first[f'{prefix}_mean_plus_sd']:.2f}]"
        )

    fig.add_annotation(
        text=f"{line('background', 'Background')}<br>{line('landslide', 'Landslide')}",
        x=0.98,
        y=0.97,
        xref="x domain",
        yref="y domain",
        xanchor="right",
        yanchor="top",
        align="left",
        showarrow=False,
        bgcolor="rgba(255,255,255,0.86)",
        bordercolor="#777777",
        borderwidth=0.8,
        borderpad=5,
        font=dict(size=11, family="Arial", color="#222222"),
        row=row,
        col=col,
    )
    fig.update_yaxes(
        title_text="Frequency (%)",
        showline=True,
        mirror=True,
        ticks="outside",
        rangemode="tozero",
        row=row,
        col=col,
    )


def export_bar_preview(lai: pd.DataFrame, slope: pd.DataFrame) -> None:
    """导出右侧两个小图的交互预览。"""
    fig = make_subplots(rows=1, cols=2, horizontal_spacing=0.12)
    _add_overlay_bars(fig, lai, "pre_lai_bin", LAI_COLOR, 1, 1, True, True, "Landslide pre-event LAI")
    _add_overlay_bars(fig, slope, "slope_bin", SLOPE_COLOR, 1, 2, False, True, "Landslide mean slope")
    _style_distribution_axes(fig, 1, 1, "Pre-event LAI")
    _style_distribution_axes(fig, 1, 2, "Slope (degree)")
    _add_statistics_annotation(fig, lai, 1, 1)
    _add_statistics_annotation(fig, slope, 1, 2)

    fig.add_annotation(text="(a)", x=0.02, y=0.97, xref="x domain", yref="y domain", showarrow=False, font=dict(size=16, family="Arial Black"))
    fig.add_annotation(text="(b)", x=0.02, y=0.97, xref="x2 domain", yref="y2 domain", showarrow=False, font=dict(size=16, family="Arial Black"))
    fig.update_layout(
        barmode="overlay",
        width=1250,
        height=500,
        template="plotly_white",
        margin=dict(l=75, r=35, t=75, b=90),
        font=dict(family="Arial", size=14, color="#111111"),
        legend=dict(orientation="h", x=0.5, xanchor="center", y=1.13, yanchor="top"),
    )
    fig.write_html(OUT_HTML, include_plotlyjs="cdn")


def _add_study_boundary(fig: go.Figure, study: gpd.GeoDataFrame) -> None:
    """把江湾镇边界作为地图轮廓加入左侧大图。"""
    for geometry in study.geometry:
        if geometry is None or geometry.is_empty:
            continue
        polygons = [geometry] if geometry.geom_type == "Polygon" else list(getattr(geometry, "geoms", []))
        for polygon in polygons:
            x, y = polygon.exterior.xy
            fig.add_trace(
                go.Scatter(
                    x=list(x),
                    y=list(y),
                    mode="lines",
                    line=dict(color="#2f2f2f", width=1.4),
                    hoverinfo="skip",
                    showlegend=False,
                ),
                row=1,
                col=1,
            )


def export_full_dashboard(lai: pd.DataFrame, slope: pd.DataFrame) -> None:
    """生成左侧滑坡地图、右侧上下背景叠置柱状图的完整 Fig.4。"""
    if not EVENTS_PATH.exists():
        raise FileNotFoundError(f"Events file not found: {EVENTS_PATH}")
    events = gpd.read_file(EVENTS_PATH)
    study = gpd.read_file(STUDY_AREA_PATH).to_crs(events.crs)
    centroids = events.geometry.centroid
    events = events.assign(_x=centroids.x, _y=centroids.y)
    events["event_year"] = pd.to_numeric(events["event_year"], errors="coerce")
    events["area_m2"] = pd.to_numeric(events["area_m2"], errors="coerce")

    fig = make_subplots(
        rows=2,
        cols=2,
        specs=[[{"type": "scatter", "rowspan": 2}, {"type": "bar"}], [None, {"type": "bar"}]],
        column_widths=[0.62, 0.38],
        row_heights=[0.5, 0.5],
        horizontal_spacing=0.10,
        vertical_spacing=0.16,
    )
    _add_study_boundary(fig, study)
    marker_size = np.clip(np.sqrt(events["area_m2"].fillna(100.0)) / 12.0, 2.5, 13.0)
    fig.add_trace(
        go.Scattergl(
            x=events["_x"],
            y=events["_y"],
            mode="markers",
            marker=dict(
                size=marker_size,
                color=events["event_year"],
                colorscale="Turbo",
                cmin=float(events["event_year"].min()),
                cmax=float(events["event_year"].max()),
                opacity=0.72,
                line=dict(color="rgba(0,0,0,0.45)", width=0.35),
                colorbar=dict(title="Event year", x=0.575, y=0.50, len=0.72, thickness=15),
            ),
            customdata=np.stack([events["event_id"].astype(str), events["area_m2"]], axis=-1),
            hovertemplate="event=%{customdata[0]}<br>area=%{customdata[1]:,.0f} m2<extra></extra>",
            showlegend=False,
        ),
        row=1,
        col=1,
    )

    _add_overlay_bars(fig, lai, "pre_lai_bin", LAI_COLOR, 1, 2, True, True, "Landslide pre-event LAI")
    _add_overlay_bars(fig, slope, "slope_bin", SLOPE_COLOR, 2, 2, False, True, "Landslide mean slope")
    _style_distribution_axes(fig, 1, 2, "Pre-event LAI")
    _style_distribution_axes(fig, 2, 2, "Slope (degree)")
    _add_statistics_annotation(fig, lai, 1, 2)
    _add_statistics_annotation(fig, slope, 2, 2)

    fig.update_xaxes(
        title_text="Easting (m)",
        showline=True,
        mirror=True,
        ticks="outside",
        tickfont=dict(size=9, color="#666666"),
        row=1,
        col=1,
    )
    fig.update_yaxes(
        title_text="Northing (m)",
        showline=True,
        mirror=True,
        ticks="outside",
        tickfont=dict(size=9, color="#666666"),
        scaleanchor="x",
        scaleratio=1,
        row=1,
        col=1,
    )

    labels = [
        ("(a)", "x domain", "y domain"),
        ("(b)", "x2 domain", "y2 domain"),
        ("(c)", "x3 domain", "y3 domain"),
    ]
    for label, xref, yref in labels:
        fig.add_annotation(
            text=label,
            x=0.02,
            y=0.97,
            xref=xref,
            yref=yref,
            showarrow=False,
            font=dict(size=16, family="Arial Black", color="#111111"),
        )

    caption = (
        "Fig. 4. Landslide distribution patterns in Jiangwan. "
        "(a) Spatial distribution of mapped landslide polygons. "
        "(b) Pre-event LAI distribution and equal-year study-area background. "
        "(c) Mean-slope distribution of landslide polygons and study-area slope background."
    )
    fig.add_annotation(
        text=caption,
        x=0.0,
        y=-0.12,
        xref="paper",
        yref="paper",
        showarrow=False,
        xanchor="left",
        align="left",
        font=dict(size=12, family="Arial", color="#222222"),
    )
    fig.update_layout(
        barmode="overlay",
        width=1500,
        height=850,
        template="plotly_white",
        margin=dict(l=85, r=60, t=105, b=120),
        font=dict(family="Arial", size=13, color="#111111"),
        title=dict(text="Fig. 4 Landslide distribution patterns", x=0.03, xanchor="left"),
        legend=dict(orientation="h", x=0.80, xanchor="center", y=1.08, yanchor="top"),
    )
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.write_html(OUT_DASHBOARD, include_plotlyjs="cdn")


def _load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """加载 Arial 字体，缺失时回退到系统默认字体。"""
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def _draw_overlay_chart(
    image: Image.Image,
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    table: pd.DataFrame,
    bin_column: str,
    title: str,
    color: str,
    y_max: float,
) -> None:
    """用 Pillow 绘制静态的背景柱与滑坡窄柱。"""
    left, top, right, bottom = box
    font = _load_font(18)
    small = _load_font(14)
    bold = _load_font(22, bold=True)
    axis_left, axis_top = left + 72, top + 55
    axis_right, axis_bottom = right - 22, bottom - 125
    plot_width, plot_height = axis_right - axis_left, axis_bottom - axis_top
    draw.text((left + 8, top + 8), title, fill="black", font=bold)

    for tick in np.linspace(0, y_max, 5):
        y = axis_bottom - tick / y_max * plot_height
        draw.line((axis_left, y, axis_right, y), fill="#dce4ee", width=1)
        draw.text((axis_left - 52, y - 8), f"{tick:.0f}", fill="black", font=small)
    draw.line((axis_left, axis_top, axis_left, axis_bottom), fill="black", width=2)
    draw.line((axis_left, axis_bottom, axis_right, axis_bottom), fill="black", width=2)

    labels = table[bin_column].astype(str).tolist()
    background = table["study_area_frequency_percent"].fillna(0.0).astype(float).tolist()
    landslides = table["landslide_frequency_percent"].fillna(0.0).astype(float).tolist()
    cell_width = plot_width / max(len(labels), 1)
    for index, (label, background_value, landslide_value) in enumerate(
        zip(labels, background, landslides)
    ):
        center = axis_left + (index + 0.5) * cell_width
        background_width = max(8, cell_width * 0.78)
        landslide_width = max(5, cell_width * 0.43)
        background_top = axis_bottom - background_value / y_max * plot_height
        landslide_top = axis_bottom - landslide_value / y_max * plot_height
        draw.rectangle(
            (center - background_width / 2, background_top, center + background_width / 2, axis_bottom),
            fill=BACKGROUND_COLOR,
            outline="#777777",
            width=1,
        )
        draw.rectangle(
            (center - landslide_width / 2, landslide_top, center + landslide_width / 2, axis_bottom),
            fill=color,
            outline="#222222",
            width=1,
        )
        label_image = Image.new("RGBA", (145, 24), (255, 255, 255, 0))
        ImageDraw.Draw(label_image).text((0, 0), label, fill="black", font=small)
        rotated = label_image.rotate(35, expand=True)
        image.paste(rotated, (int(center - 12), int(axis_bottom + 6)), rotated)

    first = table.iloc[0]
    stats_text = (
        f"Background: n={int(first['background_n']):,}, Mean={first['background_mean']:.2f}, "
        f"SD={first['background_sd']:.2f}\n"
        f"  Mean +/- SD=[{first['background_mean_minus_sd']:.2f}, "
        f"{first['background_mean_plus_sd']:.2f}]\n"
        f"Landslide: n={int(first['landslide_n']):,}, Mean={first['landslide_mean']:.2f}, "
        f"SD={first['landslide_sd']:.2f}\n"
        f"  Mean +/- SD=[{first['landslide_mean_minus_sd']:.2f}, "
        f"{first['landslide_mean_plus_sd']:.2f}]"
    )
    text_box = draw.multiline_textbbox((0, 0), stats_text, font=small, spacing=3)
    text_width = text_box[2] - text_box[0]
    text_height = text_box[3] - text_box[1]
    text_x = axis_right - text_width - 12
    text_y = axis_top + 10
    draw.rectangle(
        (text_x - 7, text_y - 6, text_x + text_width + 7, text_y + text_height + 7),
        fill="white",
        outline="#777777",
        width=1,
    )
    draw.multiline_text((text_x, text_y), stats_text, fill="#222222", font=small, spacing=3)


def export_png(lai: pd.DataFrame, slope: pd.DataFrame) -> None:
    """导出两个叠置柱状图的静态 PNG，便于快速检查。"""
    image = Image.new("RGB", (1500, 680), "white")
    draw = ImageDraw.Draw(image)
    maximum = max(
        float(lai[["study_area_frequency_percent", "landslide_frequency_percent"]].max().max()),
        float(slope[["study_area_frequency_percent", "landslide_frequency_percent"]].max().max()),
    )
    y_max = max(10.0, np.ceil(maximum / 10.0) * 10.0)
    _draw_overlay_chart(image, draw, (35, 35, 735, 645), lai, "pre_lai_bin", "(a) Pre-event LAI", LAI_COLOR, y_max)
    _draw_overlay_chart(image, draw, (765, 35, 1465, 645), slope, "slope_bin", "(b) Slope", SLOPE_COLOR, y_max)

    legend_font = _load_font(16)
    draw.rectangle((535, 14, 558, 31), fill=BACKGROUND_COLOR, outline="#777777")
    draw.text((566, 12), "Study-area background", fill="black", font=legend_font)
    draw.rectangle((790, 14, 813, 31), fill=LAI_COLOR, outline="#222222")
    draw.text((821, 12), "Landslide pre-event LAI", fill="black", font=legend_font)
    draw.rectangle((1080, 14, 1103, 31), fill=SLOPE_COLOR, outline="#222222")
    draw.text((1111, 12), "Landslide mean slope", fill="black", font=legend_font)
    image.save(OUT_PNG)


def main() -> None:
    """生成 Fig.4 叠置分布预览和完整 HTML。"""
    lai = read_overlay_table(latest_available_csv(LAI_CSV), "pre_lai_bin")
    slope = read_overlay_table(latest_available_csv(SLOPE_CSV), "slope_bin")
    export_bar_preview(lai, slope)
    export_full_dashboard(lai, slope)
    export_png(lai, slope)
    print(f"[done] {OUT_HTML}")
    print(f"[done] {OUT_PNG}")
    print(f"[done] {OUT_DASHBOARD}")


if __name__ == "__main__":
    main()
